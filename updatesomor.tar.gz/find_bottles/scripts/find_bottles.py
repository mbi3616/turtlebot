#!/usr/bin/env python
from __future__ import print_function

import roslib
#roslib.load_manifest('my_package')
import sys
import rospy
import cv2
import numpy as np
from std_msgs.msg import String
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from geometry_msgs.msg import Twist
PI = 3.1415926535897
CALIBRATE = True
USE_PICS = False
BEER = 1
WINE = 0
HAS_BORDER = False


def nothing(x):
    pass


class image_converter:

    def __init__(self, bottle_type1, bottle_type2):
        
        self.wanted_bottle_1 = bottle_type1
        self.wanted_bottle_2 = bottle_type2
        self.cols = 0
        self.rows = 0
        self.left_border = 0
        self.right_border = 0

        if USE_PICS:
            self.picture_number = 5
            name = "/home/turtlebot/catkin_ws/image" + str(self.picture_number) + ".png"
            self.cv_image = cv2.imread(name, 0)
            print("Pictures saved in catkin_ws are used ")
            self.workWithSaved()
        else:
            self.image_pub = rospy.Publisher("image_topic_2",Image,queue_size=10)
            self.twist_pub = rospy.Publisher("cmd_vel",Twist,queue_size=10)
            self.vel_msg = Twist()  
            self.bridge = CvBridge()
            self.cv_image = cv2.imread("image5.png", 0)
            self.image_sub = rospy.Subscriber("image_raw",Image,self.callback)
            self.running = False
            if self.running:
                self.turn_to_bottle()
            #self.i = 1



    def callback(self, data):
        cv2.namedWindow("PixyCam")
        if CALIBRATE:
            cv2.createTrackbar("Threshold","PixyCam",40,255,nothing)
        try:
            self.cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            print(e)

        (self.rows,self.cols,channels) = self.cv_image.shape
       
        #rotation_matrix = cv2.getRotationMatrix2D((self.cols/2, self.rows/2), -90, 1)
        #self.cv_image = cv2.warpAffine(self.cv_image, rotation_matrix, (self.cols, self.rows))
      
        """
        name = "image" + picture_number + ".png"	#str(self.i)
        cv2.imwrite(name,self.cv_image) #save pics
        #if self.i >5:			
        #	self.i +=1
        """

        self.cv_image = cv2.cvtColor(self.cv_image, cv2.COLOR_BGR2GRAY)
        value = 40
        if CALIBRATE:
            value=cv2.getTrackbarPos("Threshold", "PixyCam")

        ret,self.cv_image = cv2.threshold(self.cv_image,value,255,cv2.THRESH_BINARY)
        cv2.circle(self.cv_image, (self.cols/2, int(0.6*self.rows)), 10, 0)
        cv2.imshow("PixyCam", self.cv_image)
        #turn_to_bottle()

        try:
            self.image_pub.publish(self.bridge.cv2_to_imgmsg(self.cv_image, "8UC1"))
        except CvBridgeError as e:
            print(e)
        cv2.waitKey(100)	#time in ms
        if not self.running:
            self.running = True 


    def workWithSaved(self):
        #use saved pics:
        name = "/home/turtlebot/catkin_ws/image" + str(self.picture_number) + ".png"	  #str(self.i)
        self.cv_image = cv2.imread(name, 0)
        self.rows, self.cols = self.cv_image.shape
        #self.cv_image = cv2.cvtColor(self.cv_image, COLOR_BGR2GRAY)
        value_old = 0
        value = 40
        ret,self.cv_image = cv2.threshold(self.cv_image,value,255,cv2.THRESH_BINARY)
        if CALIBRATE:
            cv2.createTrackbar("Threshold","PixyCam",40,255,nothing)
        #if self.i >5:			
        #	self.i +=1

        while True:
            value = cv2.getTrackbarPos("Threshold", "PixyCam")
            self.cv_image = cv2.imread(name, 0)
            if value != value_old:
                value_old = value
                print("Trackbar Pose:", value)
                ret,self.cv_image = cv2.threshold(self.cv_image,value,255,cv2.THRESH_BINARY)
                cv2.imshow("PixyCam", self.cv_image)
                cv2.waitKey(4000)	#time in ms
                self.turn_to_bottle()
            cv2.waitKey(500)	#time in ms
    
    def turn_to_bottle(self):
        """
        First search for continous white space from left to right.
        Then continue searching until four bottle necks are detected and save there x position and y position
        the necks with a bigger x are the wine bottles.
        The order is given by the x value. 
        """
        bottles = np.zeros((4,2))
        #print("turn_to_bottle got called")

        bottle_cnt = 0
        purely_white_cnt = 0
        white_cnt = 0
        #print("c:", self.cols, "r:", self.rows)
        
        #find border
        """
        if self.left_border == 0 and self.right_border == 0 and HAS_BORDER:
            min_left_border = 200
            min_right_border = 200
            #print(self.cv_image[0])
            for r in range(0,self.rows):
                first_white_detected = False
                for c in range(0,self.cols): 
                    if not self.cv_image.item(r,c):  # if black
                        if first_white_detected:
                            self.right_border += 1
                        else:
                          self.left_border += 1
                    else:   # if white
                        first_white_detected = True
                        self.right_border = 0
                if self.left_border < min_left_border:
                    min_left_border = self.left_border
                if self.right_border < min_right_border:
                    min_right_border = self.right_border
                self.left_border = 0
                self.right_border = 0
            self.left_border = min_left_border
            self.right_border = min_right_border
            print("left_border", self.left_border, "right_border", self.right_border)
            print("value of pixel(0,left_border):", self.cv_image.item(0,self.left_border))
            print("value of pixel(0,right_border):", self.cv_image.item(0,self.cols - self.right_border-1))
            """


        # find area with bottles:
        black_cnt = 0
        white_cnt = 0
        bottle_widths = np.zeros(4)
        bottle_cnt = 0
        first_detected = False
        bottle_in_center = False
        count_center = 0
        first_white_cnt = 0
        r_measure = int(self.rows*0.6)
        for c in range(self.left_border,self.cols - self.right_border):    # loop through columns from left to right
            if self.cv_image.item(r_measure,c) and not first_detected:
                first_white_cnt += 1
                continue
            if first_white_cnt < 15:
                first_white_cnt = 0
                continue
            else:
                first_detected = True
            if not self.cv_image.item(r_measure,c): #if black pixel
                if white_cnt < 7:  # probably only a reflection
                    black_cnt += white_cnt 
                else:   #bigger white gap means now a new bottle detected
                    if bottle_cnt:
                        if 30 > black_cnt > 10:
                            bottle_widths[bottle_cnt] = black_cnt # save width of prior bottle
                            if bottle_cnt == 3:
                                c_end_area = c - white_cnt
                    else:   # if first bottle width not yet saved
                        if 30 > black_cnt > 10: 
                            bottle_widths[0] = black_cnt # save width of prior bottle
                            c_begin_area = c - black_cnt
                    bottle_cnt += 1
                    black_cnt = 0
                black_cnt +=1
                white_cnt = 0
            else:   #if white pixel
                white_cnt +=1
            if c == self.cols/2:
                if not self.cv_image.item(r_measure, c):    # if black
                    bottle_in_center = True
                count_center = bottle_cnt + 1
                cv2.circle(self.cv_image, (self.cols/2, r_measure), 10, 0)
                cv2.imshow("PixyCam", self.cv_image)
                if bottle_in_center:
                    print("The ", count_center, "Bottle is in the center of the picture")
                else:
                    print("The ", count_center, ". space between the bottles is in the center of the picture")
        if bottle_cnt == 3:
            bottle_widths[bottle_cnt] = black_cnt
            c_end_area = c-white_cnt
        bottle_width_mean = int(np.mean(bottle_widths))
        print("bottle widths: ",bottle_widths)
        print("mean bottle width: ",bottle_width_mean)








        # detect bottles:
        for r in range(0,self.rows):
            black_detected = False
            for c in range(c_begin_area - 10, c_end_area + 10):    
                #print(self.cv_image.item(r,c))
                #print("c:", c, "r:", r)
                if not self.cv_image.item(r,c): # if black detected in this row
                    black_detected = True
                    if purely_white_cnt > 30: #bottle detected
                        if bottle_cnt:  # if first bottle detected already
                            new_bottle = True
                            for b in range(0, bottle_cnt):
                                #print("abs(c-bottles[", b, ",1])","abs(", c, "-",bottles[b,1],")=", abs(c-bottles[b,1]))
                                if abs(c-bottles[b,1]) < 30:  #same bottle as bottles[b] detected
                                    new_bottle = False
                                    break
                            if new_bottle:
                                bottles[bottle_cnt] = r,c
                                bottle_cnt += 1
                                print(bottle_cnt, ". bottle detected at c:",bottles[bottle_cnt-1,1], "r:", bottles[bottle_cnt-1,0] )
                                if bottle_cnt >= 4:
                                    c = self.cols - 1
                                    r = self.rows - 1
                        else:   #first bottle
                          bottles[0] = r,c
                          bottle_cnt += 1
                          print("1st bottle detected at c:",bottles[0,1], "r:", bottles[0,0])

                    elif white_cnt < (self.cols - self.left_border - self.right_border -1):
                        purely_white_cnt = 0
                        break
            if not black_detected:
                purely_white_cnt += 1
                #print("purely_white_cnt: ", purely_white_cnt)
        
        """    
        for b in range(0,4):    
            print("bottle ", b+1,"at r:", bottles[b,0], "c:", bottles[b,1])      
            cv2.circle(self.cv_image, (int(bottles[b,1]), int(bottles[b,0])), 10, 0)
        """
        print("Bottles have been identified. /n Now the roboter will turn to the first desired bottle.")
        """# bottle position: the first value is the left most bottle, 
        the last value is the right most bottle.
        Tthe value itself is giving information if its a wine or beer bottle. 
        If the value is less or equal 1 its a wine bottle
        """
        bottle_order = np.argsort(bottles[:,1])   
        print(bottle_order)
        print("From left to write we have the following order:")
        for x in range(0,4):
            if(bottle_order[x]<2):
                    print(x+1, ". WINE")
            else:
                    print(x+1, ". BEER")

        # FIND POSITION OF BOTTLE BOTTOM
        black_cnt = 0
        bottom_pos = np.zeros(4)
        bottle_length = np.zeros(4)
        white_cnt = 0
        for bottle in range(0, bottle_cnt):
            for r in range(int(bottles[bottle,0]), self.rows):
                if not self.cv_image.item(r,int(bottles[bottle,1])): #if black pixel
                    if white_cnt:
                        black_cnt += white_cnt
                        white_cnt = 0
                    black_cnt +=1
                else: # white pixel
                    white_cnt +=1
                    
                if white_cnt > 18:
                    break
            bottom_pos[bottle] = black_cnt + bottles[bottle,0]
            bottle_length[bottle] = black_cnt
            black_cnt = 0
            white_cnt = 0
        
        bottle_length_mean = int(np.mean(bottle_length))
        bottom_mean = int(np.mean(bottom_pos))
        print ("bottle_length_mean", bottle_length_mean)
        print ("bottom_mean", bottom_mean)
        r_measure = int(bottom_mean-0.4*bottle_length_mean)
        print ("r_measure", r_measure)
        #cv2.circle(self.cv_image, (self.cols/2, r_measure), 10, 0)

        """
        # measure bottle_widths at the current position:
        black_cnt = 0
        white_cnt = 0
        bottle_widths = np.zeros(4)
        bottle_cnt = 0
        first_detected = False
        self.cv_image.item(r_measure,self.cols/2)
        bottle_in_center = False
        count_center = 0

        for c in range(self.left_border,self.cols - self.right_border):    # loop through columns from left to right
            if  self.cv_image.item(r_measure,c) and not first_detected:
                continue
            first_detected = True
            if not self.cv_image.item(r_measure,c): #if black pixel
                if white_cnt < 7:  # probably only a reflection
                    black_cnt += white_cnt 
                else:   #bigger white gap means now a new bottle detected
                    if bottle_cnt:
                        bottle_widths[bottle_cnt] = black_cnt # save width of prior bottle
                    else:   # if first bottle width not yet saved
                        bottle_widths[0] = black_cnt # save width of prior bottle
                    bottle_cnt += 1
                    black_cnt = 0
                black_cnt +=1
                white_cnt = 0
            else:   #if white pixel
                white_cnt +=1
            if c == self.cols/2:
                if not self.cv_image.item(r_measure, c):    # if black
                    bottle_in_center = True
                count_center = bottle_cnt + 1
                cv2.circle(self.cv_image, (self.cols/2, r_measure), 10, 0)
                cv2.imshow("PixyCam", self.cv_image)
                if bottle_in_center:
                    print("The ", count_center, "Bottle is in the center of the picture")
                else:
                    print("The ", count_center, ". space between the bottles is in the center of the picture")
        bottle_widths[bottle_cnt] = black_cnt
        bottle_width_mean = int(np.mean(bottle_widths))
        print("bottle widths: ",bottle_widths)
        print("mean bottle width: ",bottle_width_mean)
        """


        cv2.imshow("PixyCam", self.cv_image)

        self.vel_msg.linear.x = 0
        self.vel_msg.linear.y = 0
        self.vel_msg.linear.z = 0 
        self.vel_msg.angular.x = 0
        self.vel_msg.angular.y = 0
        self.vel_msg.angular.z = 0

        if self.wanted_bottle_1 == WINE:
            bottle_pos = np.argwhere(bottle_order == 3)
        else:
            bottle_pos = np.argwhere(bottle_order == 0)
        print(bottle_pos)
        w2b_trans = 0
        if not bottle_in_center:
            if bottle_pos + 1 < count_center:
                w2b_trans = count_center - bottle_pos
                self.vel_msg.angular.z = 0.5
            elif bottle_pos + 1 > count_center:
                w2b_trans = bottle_pos + 1 - count_center
                self.vel_msg.angular.z = -0.5
            else:   # equal
                w2b_trans = 1
                self.vel_msg.angular.z = -0.5
        else:
            if bottle_pos + 1 < count_center:
                w2b_trans = count_center - bottle_pos - 1
                self.vel_msg.angular.z = 0.5
            elif bottle_pos + 1 > count_center:
                w2b_trans = bottle_pos + 1 - count_center 
                self.vel_msg.angular.z = -0.5

        
        # count the transitions from white to black (wall to bottle)
        w2b_tbd = 0
        white_before = False
        self.twist_pub.publish(self.vel_msg)
        self.vel_msg.angular.z = 0
        while(w2b_trans > w2b_tbd):
            if self.cv_image.item(r_measure,self.cols/2):   # white = wall
                white_before = True
                #print("White in center")
            else:
                if white_before:
                    w2b_tbd += 1
                white_before = False
                #print("Black in center")
        self.twist_pub.publish(vel_msg)

        


def main(args):

    rospy.init_node('image_converter', anonymous=True)
    ic = image_converter(BEER, WINE)
    try:
        rospy.spin()
    except KeyboardInterrupt:
        print("Shutting down")
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main(sys.argv)
