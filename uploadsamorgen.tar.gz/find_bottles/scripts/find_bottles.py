#!/usr/bin/env python
from __future__ import print_function

import roslib
#roslib.load_manifest('my_package')
import sys
import rospy
import cv2
import numpy as np
from std_msgs.msg import String
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
CALIBRATE = True
USE_PICS = True
BEER = 1
WINE = 0
HAS_BORDER = True

def nothing(x):
    pass


class image_converter:

    def __init__(self, bottle_type1, bottle_type2):
        cv2.namedWindow('PixyCam')
        self.wanted_bottle_1 = bottle_type1
        self.wanted_bottle_2 = bottle_type2
        self.cols = 0
        self.rows = 0
        self.left_border = 0
        self.right_border = 0

        if USE_PICS:
            self.picture_number = 5
            name = "/home/turtlebot/catkin_ws/image" + str(self.picture_number) + ".png"
            self.cv_image = cv2.imread(name, 0)
            print("Pictures saved in catkin_ws are used ")
            self.workWithSaved()
        else:
            self.image_pub = rospy.Publisher("image_topic_2",Image,queue_size=10)
            self.bridge = CvBridge()
            self.cv_image = rospy.wait_for_message("image_raw", Image, 10)
            self.image_sub = rospy.Subscriber("image_raw",Image,self.callback)
            #self.i = 1
            if CALIBRATE:
                cv2.createTrackbar("Threshold","PixyCam",40,255,nothing)

    def callback(self, data):
        try:
            self.cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            print(e)

        (self.cols,self.rows,channels) = self.cv_image.shape
        rotation_matrix = cv2.getRotationMatrix2D((cols/2, rows/2), -90, 1)
        self.cv_image = cv2.warpAffine(self.cv_image, rotation_matrix, (cols, rows))
      
        """
        name = "image" + picture_number + ".png"	#str(self.i)
        cv2.imwrite(name,self.cv_image) #save pics
        #if self.i >5:			
        #	self.i +=1
        """
        self.cv_image = cv2.cvtColor(self.cv_image, cv2.COLOR_BGR2GRAY)
        if CALIBRATE:
            value=cv2.getTrackbarPos("Threshold", "PixyCam")
        else:
            value = 40

        ret,self.cv_image = cv2.threshold(self.cv_image,value,255,cv2.THRESH_BINARY)

        cv2.imshow("PixyCam", self.cv_image)
        #turn_to_bottle()

        try:
            self.image_pub.publish(self.bridge.cv2_to_imgmsg(self.cv_image, "8UC1"))
        except CvBridgeError as e:
            print(e)
        cv2.waitKey(100)	#time in ms


    def workWithSaved(self):
        #use saved pics:
        name = "/home/turtlebot/catkin_ws/image" + str(self.picture_number) + ".png"	  #str(self.i)
        self.cv_image = cv2.imread(name, 0)
        self.rows, self.cols = self.cv_image.shape
        #self.cv_image = cv2.cvtColor(self.cv_image, COLOR_BGR2GRAY)
        value_old = 0
        value = 40
        ret,self.cv_image = cv2.threshold(self.cv_image,value,255,cv2.THRESH_BINARY)
        if CALIBRATE:
            cv2.createTrackbar("Threshold","PixyCam",40,255,nothing)
        #if self.i >5:			
        #	self.i +=1

        while True:
            value = cv2.getTrackbarPos("Threshold", "PixyCam")
            self.cv_image = cv2.imread(name, 0)
            if value != value_old:
                value_old = value
                print("Trackbar Pose:", value)
                ret,self.cv_image = cv2.threshold(self.cv_image,value,255,cv2.THRESH_BINARY)
                cv2.imshow("PixyCam", self.cv_image)
                cv2.waitKey(4000)	#time in ms
                self.turn_to_bottle()
            cv2.waitKey(500)	#time in ms
    
    def turn_to_bottle(self):
        """
        First search for continous white space from left to right.
        Then continue searching until four bottle necks are detected and save there x position and y position
        the necks with a bigger x are the wine bottles.
        The order is given by the x value. 
        """
        bottles = np.zeros((4,2))
        #print("turn_to_bottle got called")

        bottle_cnt = 0
        purely_white_cnt = 0
        white_cnt = 0
        #print("c:", self.cols, "r:", self.rows)
        
        #find border
        if self.left_border == 0 and self.right_border == 0 and HAS_BORDER:
            min_left_border = 200
            min_right_border = 200
            #print(self.cv_image[0])
            for r in range(0,self.rows):
                first_white_detected = False
                for c in range(0,self.cols): 
                    if not self.cv_image.item(r,c):  # if black
                        if first_white_detected:
                            self.right_border += 1
                        else:
                          self.left_border += 1
                    else:   # if white
                        first_white_detected = True
                        self.right_border = 0
                if self.left_border < min_left_border:
                    min_left_border = self.left_border
                if self.right_border < min_right_border:
                    min_right_border = self.right_border
                self.left_border = 0
                self.right_border = 0
            self.left_border = min_left_border
            self.right_border = min_right_border
            print("left_border", self.left_border, "right_border", self.right_border)
            print("value of pixel(0,left_border):", self.cv_image.item(0,self.left_border))
            print("value of pixel(0,right_border):", self.cv_image.item(0,self.cols - self.right_border-1))


        for r in range(0,self.rows):
            black_detected = False
            for c in range(self.left_border,self.cols - self.right_border):    
                #print(self.cv_image.item(r,c))
                #print("c:", c, "r:", r)
                if not self.cv_image.item(r,c): # if black detected in this row
                    black_detected = True
                    if purely_white_cnt > 30: #bottle detected
                        if bottle_cnt:  # if first bottle detected already
                            new_bottle = True
                            for b in range(0, bottle_cnt):
                                #print("abs(c-bottles[", b, ",1])","abs(", c, "-",bottles[b,1],")=", abs(c-bottles[b,1]))
                                if abs(c-bottles[b,1]) < 30:  #same bottle as bottles[b] detected
                                    new_bottle = False
                                    break
                            if new_bottle:
                                bottles[bottle_cnt] = r,c
                                bottle_cnt += 1
                                print(bottle_cnt, ". bottle detected at c:",bottles[bottle_cnt-1,1], "r:", bottles[bottle_cnt-1,0] )
                                if bottle_cnt >= 4:
                                    c = self.cols - 1
                                    r = self.rows - 1
                        else:   #first bottle
                          bottles[0] = r,c
                          bottle_cnt += 1
                          print("1st bottle detected at c:",bottles[0,1], "r:", bottles[0,0])

                    elif white_cnt < (self.cols - self.left_border - self.right_border -1):
                        purely_white_cnt = 0
                        break
            if not black_detected:
                purely_white_cnt += 1
                #print("purely_white_cnt: ", purely_white_cnt)

            
        for b in range(0,4):    
            print("bottle ", b+1,"at r:", bottles[b,0], "c:", bottles[b,1])      
            cv2.circle(self.cv_image, (int(bottles[b,1]), int(bottles[b,0])), 10, 0)
        
        print("for finished")
        cv2.imshow("PixyCam", self.cv_image)
        cv2.waitKey(4000)	#time in ms
        print("pic updated")







def main(args):
    ic = image_converter(BEER, WINE)
    rospy.init_node('image_converter', anonymous=True)
    try:
        rospy.spin()
    except KeyboardInterrupt:
        print("Shutting down")
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main(sys.argv)
