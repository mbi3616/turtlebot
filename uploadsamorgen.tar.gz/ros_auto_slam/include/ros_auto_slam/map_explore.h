#include "ros/ros.h"
#include "std_msgs/String.h"
#include "std_msgs/Float64.h"
#include "move_base_msgs/MoveBaseAction.h"
#include "move_base_msgs/MoveBaseGoal.h"
#include <actionlib/client/simple_action_client.h>
#include <ros_auto_slam/FollowWallAction.h>
#include <ros_auto_slam/ExploreRemainderAction.h>
#include "sensor_msgs/LaserScan.h"
#include "geometry_msgs/Point.h"
#include "geometry_msgs/PointStamped.h"
#include <tf/transform_listener.h>

#include <stdint.h>
#include <algorithm>
#include <cmath>
using namespace std;

#define MAX_FREE_CELL_VALUE 5   //a value close to 0 is considered as unoccupied cell
#define PI 3.141592
#define TURTLE_RADIUS 0.105 