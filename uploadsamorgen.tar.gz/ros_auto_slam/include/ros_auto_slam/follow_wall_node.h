/*#include <ros/ros.h>
#include <actionlib/server/simple_action_server.h>
#include <ros_auto_slam/FollowWallAction.h>
#include "sensor_msgs/LaserScan.h"
#include "geometry_msgs/Twist.h"
#include "geometry_msgs/Point.h"
#include <tf/transform_listener.h>
#include <math.h>
#define PI 3.141592


class FollowWallAction{
    public:
        //variables
        double wallDistance; // Desired distance from the wall.
        double e;            // Difference between desired distance from the wall and actual distance.
        double diffE;     // Derivative element for PD controller;
        double maxSpeed;     // Maximum speed of robot.
        double P;            // k_P Constant for PD controller.
        double D;            // k_D Constant for PD controller.
        double angleCoef;    // Coefficient for P controller.
        int direction;      // 1 for wall on the right side of the robot (-1 for the left one).
        double angleMin;     // Angle, at which was measured the shortest distance.
        double distFront;    // Distance, measured by ranger in front of robot.
        ros::Publisher pubMessage;  // Object for publishing messages.

        //ros::NodeHandle nh;
        actionlib::SimpleActionServer<ros_auto_slam::FollowWallAction> *as;
        //std::string action_name;

        ros_auto_slam::FollowWallFeedback feedback;
        ros_auto_slam::FollowWallResult result;

        /*FollowWallAction(std::string name, actionlib::SimpleActionServer<ros_auto_slam::FollowWallAction> as, double wallDist, double maxSp, int dir, double pr, double di, double an) : 
        as(nh,name, boost::bind(&FollowWallAction::executeActionCB, this, _1),false){
            *//*
        FollowWallAction(actionlib::SimpleActionServer<ros_auto_slam::FollowWallAction> *as_, double wallDist, double maxSp, int dir, double pr, double di, double an){
            as = as_;
            (*as)()
            //action_name = name;
            wallDistance = wallDist;
            maxSpeed = maxSp;
            direction = dir;
            P = pr;
            D = di;
            angleCoef = an;
            e = 0;
            angleMin = 0;  //angle, at which was measured the shortest distance
            pubMessage = nh.advertise<geometry_msgs::Twist>("/cmd_vel", 1000);
            (*as).start();
            ROSINFO("as.start() got executed");
        }

        ~FollowWallAction(void){}



        void executeActionCB(const ros_auto_slam::FollowWallGoalConstPtr & goal);
        void executeScanCB(const sensor_msgs::LaserScan msg);

};

*/