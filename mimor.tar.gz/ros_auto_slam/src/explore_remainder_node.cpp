#include "ros/ros.h"
#include <actionlib/server/simple_action_server.h>
#include <ros_auto_slam/ExploreRemainderAction.h>
#include "nav_msgs/GetMap.h"
#include <actionlib/client/simple_action_client.h> 	 // action Library Header File
#include "move_base_msgs/MoveBaseAction.h"
#include "move_base_msgs/MoveBaseGoal.h"
#include "sensor_msgs/LaserScan.h"
#include "geometry_msgs/Twist.h"
#include <stdint.h>

#define TURTLE_RADIUS 0.105
#define MAX_FREE_CELL_VALUE 5   //a value close to 0 is considered as unoccupied cell
#define PI 3.141592
using namespace std;
typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;

class ExploreRemainderAction{

    protected:


    ros::NodeHandle nh;            // Node handle declaration
    actionlib::SimpleActionServer<ros_auto_slam::ExploreRemainderAction> as_;    // Action server declaration
    std::string action_name_;       // Use as action name
    ros_auto_slam::ExploreRemainderFeedback feedback_;      // Declare the action feedback and the result to Publish
    ros_auto_slam::ExploreRemainderResult result_;
    ros::ServiceClient get_map_client;

    nav_msgs::GetMap get_map_srv;
    int height;
    int width;
    double resolution;
    double x_origin;
    double y_origin;

    public:
    int8_t **new_goal_grid;     // this grid is for showing where a transition from an unoccupied to an unknown cell is
    int8_t **occupancy_grid_2d;

    // Initialize action server (Node handle, action name, action callback function)
    ExploreRemainderAction(std::string name) : as_(nh, name, boost::bind(&ExploreRemainderAction::executeCB,
    this, _1), false){
        action_name_ = name;
        get_map_client = nh.serviceClient<nav_msgs::GetMap>("dynamic_map");
        get_map_client.call(get_map_srv);     
        height = get_map_srv.response.map.info.height;
        width = get_map_srv.response.map.info.width;
        resolution = get_map_srv.response.map.info.resolution;
        x_origin = get_map_srv.response.map.info.origin.position.x;
        y_origin = get_map_srv.response.map.info.origin.position.y; 
      
        ROS_INFO("x_origin: %f", get_map_srv.response.map.info.origin.position.x);
        ROS_INFO("y_origin: %f", get_map_srv.response.map.info.origin.position.y);
        ROS_INFO("Height: %ld", (long int)get_map_srv.response.map.info.height);
        ROS_INFO("Width: %ld", (long int)get_map_srv.response.map.info.width);
        ROS_INFO("Resolution: %f", get_map_srv.response.map.info.resolution);
        //new_goal_grid [height][width] = {0}; 
        occupancy_grid_2d = new int8_t*[height];
        for(int i = 0; i<height; i++){
            occupancy_grid_2d[i] = new int8_t[width];
        }
        
        create2DOccupancyGrid();
        as_.start();
    }

    ~ExploreRemainderAction(void){
        for(int i = 0; i<height; i++){
            delete [] occupancy_grid_2d[i];
        }
        delete [] occupancy_grid_2d;
    }

   void create2DOccupancyGrid(){
        int8_t occupancy_grid_1d[height*width];
        copy(get_map_srv.response.map.data.begin(),get_map_srv.response.map.data.end(),occupancy_grid_1d);

        //creating 2D Occupancy Grid
        for(int row = 0; row < height; row++){
            copy(occupancy_grid_1d + width*row, occupancy_grid_1d + width*(row+1), occupancy_grid_2d[row]);
        }
        ROS_INFO("2D Occupancy Grid was created");
   }
   
    // A function that receives an action goal message and performs a specified action
    void executeCB(const ros_auto_slam::ExploreRemainderGoalConstPtr &goal)
    {
        MoveBaseClient ac_move_base("move_base", true); 
        if (get_map_client.call(get_map_srv))
        {   
            //----------------evaluate transition pixels from unocuppied cell to unknown cell:--------------------
            bool previous_cell_unknown;
            bool previous_cell_free = false;
            bool first_occupied_cell_found = false;
            bool transition_found = false;
            int possible_free_cnt = 0;
            int consecutively_free_cnt = 0;
            int consecutively_free_max = 0;
            int consecutively_unknown_cnt = 0;
            int consecutively_unknown_max = 0;
            bool exploring_finished = false;
            bool x_dir;
            create2DOccupancyGrid();
            (occupancy_grid_2d[0][0]==-1) ? (previous_cell_unknown = true) : (previous_cell_unknown = false);

            while(!exploring_finished){
                exploring_finished = true;
                //find transition pixels in x:
                x_dir = true;
                ROS_INFO("find transition pixels in x:");
                for(int row = (goal->y_min-y_origin)/resolution; row < (goal->y_max-y_origin)/resolution; row++){
                    //ROS_INFO("row: %d",row);
                    for(int col = (goal->x_min-x_origin)/resolution; col < (goal->x_max-x_origin)/resolution; col++){
                        if(detect_unexplored(x_dir, ac_move_base, row, col, previous_cell_unknown, previous_cell_free, first_occupied_cell_found, transition_found, possible_free_cnt, consecutively_free_cnt, consecutively_free_max, consecutively_unknown_cnt, consecutively_unknown_max)){
                            exploring_finished = false;
                        }
                    }  // end for col
                    previous_cell_free = false;
                    transition_found = false;
                    first_occupied_cell_found = false;
                    previous_cell_unknown = true;
                    possible_free_cnt = 0;
                    consecutively_free_cnt = 0;
                    consecutively_free_max = 0;
                    consecutively_unknown_cnt = 0;
                    consecutively_unknown_max = 0;
                    consecutively_unknown_cnt = 0;
                    consecutively_unknown_max = 0;
                }   //end for row

                (occupancy_grid_2d[0][0]==-1) ? (previous_cell_unknown = true) : (previous_cell_unknown = false);
                //find transition pixels in y:
                x_dir=false;
                ROS_INFO("find transition pixels in y:");
                for(int col = (goal->x_min-x_origin)/resolution; col < (goal->x_max-x_origin)/resolution; col++){
                    //ROS_INFO("col: %d",col);
                    for(int row = (goal->y_min-y_origin)/resolution; row < (goal->y_max-y_origin)/resolution; row++){
                        if(detect_unexplored(x_dir, ac_move_base, row, col, previous_cell_unknown, previous_cell_free, first_occupied_cell_found, transition_found, possible_free_cnt, consecutively_free_cnt, consecutively_free_max, consecutively_unknown_cnt, consecutively_unknown_max)){
                            exploring_finished = false;
                        }
                    }  // end for row
                    previous_cell_free = false;
                    transition_found = false;
                    first_occupied_cell_found = false;
                    previous_cell_unknown = true;
                    possible_free_cnt = 0;
                    consecutively_free_cnt = 0;
                    consecutively_free_max = 0;                
                    consecutively_unknown_cnt = 0;
                    consecutively_unknown_max = 0;
                }   //end for col
            }
            

/*
        ros::Rate r(1);		 // Loop Rate: 1Hz
        bool success = true;	 // Used as a variable to store the success or failure of an action

        if (as_.isPreemptRequested() || !ros::ok())
        {
            // Notify action cancellation
            ROS_INFO("%s: Preempted", action_name_.c_str());
            as_.setPreempted();		 // Action cancellation
            success = false;		 // Consider action as failure and save to variable
        }


         
        r.sleep();					 // sleep according to the defined loop rate.
        */
        ROS_INFO("executeCB finished");
        }   // end if (get_map_client.call(get_map_srv))
        else{
            ROS_ERROR("Failed to call service nav_msgs/GetMap");
        }
        result_.success = true;
        as_.setSucceeded(result_);
    }   // end executeCB



    bool detect_unexplored(bool x_dir, MoveBaseClient &ac_move_base, int &row, int &col, bool &previous_cell_unknown, bool &previous_cell_free, bool &first_occupied_cell_found, bool &transition_found, int &possible_free_cnt, int &consecutively_free_cnt, int &consecutively_free_max, int &consecutively_unknown_cnt, int &consecutively_unknown_max){
        int row_transition;
        int col_transition;
        if(!first_occupied_cell_found){
            if(occupancy_grid_2d[row][col] > MAX_FREE_CELL_VALUE){  // first occupied cell found (inside maze now)
                first_occupied_cell_found = true;   
                previous_cell_free = false;
                //ROS_INFO("first occupied cell in row: %d col: %d found at x: %f y: %f", row, col, (col-possible_free_cnt/2)*resolution+x_origin, row*resolution+y_origin);
            }
            return false;
        }else if(occupancy_grid_2d[row][col]==-1){    // if UNKNOWN cell AND first_occupied_cell_found == true
            if(previous_cell_free){     // UNKNOWN cell with UNOCCUPIED neighbour on the left found
                if(consecutively_free_cnt>consecutively_free_max){
                    consecutively_free_max = consecutively_free_cnt;  
                    transition_found = true;               
                }
                consecutively_free_cnt = 0;
            }else if(previous_cell_unknown){
                consecutively_unknown_cnt++;
            }
            possible_free_cnt++;
            previous_cell_unknown = true;
            previous_cell_free = false;
            return false;       
        }
        else{   // if KNOWN cell
            
            if(occupancy_grid_2d[row][col] < MAX_FREE_CELL_VALUE){  //if UNOCCUPIED cell found
                if( previous_cell_unknown){     // if UNKNOWN left neighbour
                    if(consecutively_unknown_cnt>consecutively_unknown_max){
                        consecutively_unknown_max = consecutively_unknown_cnt;   
                        transition_found = true;
                        col_transition = col;
                        row_transition = row;              
                    }
                    consecutively_unknown_cnt = 0;
                }
                if(previous_cell_free){   // consecutively UNOCCUPIED cells found
                    consecutively_free_cnt++;   
                }
                possible_free_cnt++;
                previous_cell_free = true;
                
            }else{      // if further OCCUPIED cell in current col found
                if(consecutively_free_cnt>consecutively_free_max){
                    consecutively_free_max = consecutively_free_cnt;                 
                }
                if(consecutively_unknown_cnt>consecutively_unknown_max){
                    consecutively_unknown_max = consecutively_unknown_cnt;               
                }

                //ROS_INFO("further OCCUPIED cell in row: %d col: %d found at x: %f y: %f", row, col, (col-possible_free_cnt/2)*resolution+x_origin, row*resolution+y_origin);
                //ROS_INFO("consecutively_free_max: %d possible_free_cnt: %d", consecutively_free_max, possible_free_cnt);

                if(transition_found && possible_free_cnt > 3*TURTLE_RADIUS/resolution && consecutively_free_max >2.5*TURTLE_RADIUS/resolution && consecutively_unknown_max >2){
                    //send move_base goal
                    //ROS_INFO("2ND OCCUPIED cell in row: %d col: %d found at x: %f y: %f", row, col, (col-possible_free_cnt/2)*resolution+x_origin, row*resolution+y_origin);
                    while(!ac_move_base.waitForServer(ros::Duration(5.0))){
                        ROS_INFO("Waiting for the move_base action server to come up");
                    }

                    move_base_msgs::MoveBaseGoal goal;
                    

                    double cell_num = 1.8*TURTLE_RADIUS/resolution;
                    int cell_n = (int)cell_num;
                    
                    for(int c=col_transition-cell_n; c<(col_transition+cell_n); c++){
                        for(int r=row_transition-cell_n; r<(row_transition+cell_n);r++){
                            if(occupancy_grid_2d[r][c]>MAX_FREE_CELL_VALUE){
                                previous_cell_free = false;
                                transition_found = false;
                                possible_free_cnt = 0;
                                consecutively_free_cnt = 0;
                                consecutively_free_max = 0;
                                return false;
                            }
                        }
                    }


                    goal.target_pose.pose.position.x = col_transition*resolution+x_origin;
                    goal.target_pose.pose.position.y = row_transition*resolution+y_origin;


                    goal.target_pose.header.frame_id = "map";
                    goal.target_pose.header.stamp = ros::Time::now();
                    goal.target_pose.pose.orientation.w = 1;

                    ROS_INFO("col: %d row: %d resolution: %f possible_free_cnt: %d x: %f y: %f ",col_transition, row_transition, resolution, possible_free_cnt, col_transition*resolution+x_origin, row_transition*resolution+y_origin);
                    ROS_INFO("Sending goal x=%f y=%f ", goal.target_pose.pose.position.x, goal.target_pose.pose.position.y);
                    
                    int cnt = 0;
                    while(cnt<=3){

                        ac_move_base.sendGoal(goal);
                        ac_move_base.waitForResult();
                        actionlib::SimpleClientGoalState state =ac_move_base.getState();
                        if(ac_move_base.getState() == actionlib::SimpleClientGoalState::SUCCEEDED){
                            ROS_INFO("Destination successfully reached.");
                        }else if(ac_move_base.getState() == actionlib::SimpleClientGoalState::ABORTED){
                            ROS_INFO("manual recovery neccessary via cmd_vel");
                            sensor_msgs::LaserScan laser_msg = *(ros::topic::waitForMessage<sensor_msgs::LaserScan>("/scan"));
                            ros::Publisher pubMessage = nh.advertise<geometry_msgs::Twist>("/cmd_vel", 1000);;  // Object for publishing messages.
                            //This cycle goes through array and finds minimum
                            int maxIndex = laser_msg.ranges.size();
                            int minIndex = 0;
                            for(int i = 0; i < maxIndex; i++)    //going from back to the front in counter clockwise direction
                            {
                                if (laser_msg.ranges[i] < laser_msg.ranges[minIndex] && laser_msg.ranges[i] > 0.0){
                                    minIndex = i;
                                }           
                            }
                            int angleMin = (minIndex)*laser_msg.angle_increment; 
                            geometry_msgs::Twist Twistmsg;
                            if(angleMin > PI){
                                Twistmsg.angular.z = -2.5; //rad/sec
                            }else{
                                Twistmsg.angular.z = 2.5; //rad/sec
                            }
                                
                            pubMessage.publish(Twistmsg);//publishing message
                            Twistmsg.angular.z = 0;
                            Twistmsg.linear.x = 0.1;
                            while(minIndex<maxIndex/2-3 && minIndex>maxIndex/2+3){
                                for(int i = 0; i < maxIndex; i++)    //going from back to the front in counter clockwise direction
                                {
                                    if (laser_msg.ranges[i] < laser_msg.ranges[minIndex] && laser_msg.ranges[i] > 0.0){
                                        minIndex = i;
                                    }           
                                }
                            }
                            pubMessage.publish(Twistmsg);//publishing message
                            Twistmsg.angular.z = 0;
                            Twistmsg.linear.x = 0;
                            while(laser_msg.ranges[0]>laser_msg.ranges[(int)maxIndex/2]){}
                            pubMessage.publish(Twistmsg);//publishing message
                            cnt++;   
                        } else if(ac_move_base.getState() == actionlib::SimpleClientGoalState::REJECTED){
                            cnt =3;
                        }
                    }

                    if (get_map_client.call(get_map_srv)){
                        create2DOccupancyGrid();
                    }else{ROS_ERROR("Failed to call service nav_msgs/GetMap");}

                previous_cell_free = false;
                transition_found = false;
                possible_free_cnt = 0;
                consecutively_free_cnt = 0;
                consecutively_free_max = 0;
                    return true;
                }   //end of if(transition_found && possible_free_cnt > 3*TURTLE_RADIUS/resolution....)
                previous_cell_free = false;
                transition_found = false;
                possible_free_cnt = 0;
                consecutively_free_cnt = 0;
                consecutively_free_max = 0;
            }   //end else // if further OCCUPIED cell in current row/col found
            previous_cell_unknown = false;
            return false;
        }   //end else{   // if KNOWN cell
    }   // end detect_unexplored


};  // end class ExploreRemainderAction



int main(int argc, char** argv)		// Node Main Function
{
    ros::init(argc, argv, "explore_remainder");		// Initializes Node Name
    //actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> ac_move_base("move_base", true); 
    // ExploreRemainder Declaration(Action Name: explore_remainder)
    ExploreRemainderAction explore_remainder("explore_remainder");
    ros::spin();    // Wait to receive action goal						
    return 0;
}