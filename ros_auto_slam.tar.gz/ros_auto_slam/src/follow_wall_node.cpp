//#include "ros_auto_slam/follow_wall_node.h"
#include <ros/ros.h>
#include <actionlib/server/simple_action_server.h>
#include <ros_auto_slam/FollowWallAction.h>
#include "sensor_msgs/LaserScan.h"
#include "geometry_msgs/Twist.h"
#include "geometry_msgs/Point.h"
#include <tf/transform_listener.h>
#include <math.h>
#define PI 3.141592


#define SUBSCRIBER_BUFFER_SIZE 1  // Size of buffer for subscriber.
#define PUBLISHER_BUFFER_SIZE 1000  // Size of buffer for publisher.
#define WALL_DISTANCE 0.13
#define MAX_SPEED 0.1
#define P 10    // Proportional constant for controller
#define D 5     // Derivative constant for controller
#define ANGLE_COEF 1    // Proportional constant for angle controller
#define DIRECTION 1 // 1 for wall on the left side of the robot (-1 for the right side).
// #define PUBLISHER_TOPIC "/syros/base_cmd_vel"
#define PUBLISHER_TOPIC "/cmd_vel"
// #define SUBSCRIBER_TOPIC "/syros/laser_laser"
//#define SUBSCRIBER_TOPIC "/base_scan"
#define SUBSCRIBER_TOPIC "/scan"


class FollowWallAction{
    public:
        //variables
        double wallDistance; // Desired distance from the wall.
        double e;            // Difference between desired distance from the wall and actual distance.
        double diffE;     // Derivative element for PD controller;
        double maxSpeed;     // Maximum speed of robot.
        double p;            // k_P Constant for PD controller.
        double d;            // k_D Constant for PD controller.
        double angleCoef;    // Coefficient for P controller.
        int direction;      // 1 for wall on the right side of the robot (-1 for the left one).
        double angleMin;     // Angle, at which was measured the shortest distance.
        double distFront;    // Distance, measured by ranger in front of robot.
        ros::Publisher pubMessage;  // Object for publishing messages.

        ros::NodeHandle nh;
        actionlib::SimpleActionServer<ros_auto_slam::FollowWallAction> as;
        std::string action_name;

        ros_auto_slam::FollowWallFeedback feedback;
        ros_auto_slam::FollowWallResult result;

        FollowWallAction(std::string name, double wallDist, double maxSp, int dir, double pr, double di, double an) : 
        as(nh,name, boost::bind(&FollowWallAction::executeActionCB, this, _1),false){
            action_name = name;
            wallDistance = wallDist;
            maxSpeed = maxSp;
            direction = dir;
            p = pr;
            d = di;
            angleCoef = an;
            e = 0;
            angleMin = 0;  //angle, at which was measured the shortest distance
            pubMessage = nh.advertise<geometry_msgs::Twist>("/cmd_vel", 1000);
            as.start();
            ROS_INFO("as.start() got executed");
        }

        ~FollowWallAction(void){}


        void executeActionCB(const ros_auto_slam::FollowWallGoalConstPtr & goal);
        void executeScanCB(const sensor_msgs::LaserScan msg);

};


void FollowWallAction::executeScanCB(const sensor_msgs::LaserScan laser_msg){
     ROS_INFO("FollowWallAction::executeScanCB");
     int size = laser_msg.ranges.size();

    //Variables whith index of highest and lowest value in array.
    int minIndex = size*(direction+1)/4;
    int maxIndex = size*(direction+3)/4;

    //This cycle goes through array and finds minimum
    for(int i = minIndex; i < maxIndex; i++)
    {
        if (laser_msg.ranges[i] < laser_msg.ranges[minIndex] && laser_msg.ranges[i] > 0.0){
            minIndex = i;
        }           
    }

    //Calculation of angles from indexes and storing data to class variables.
    angleMin = (minIndex-size/2)*laser_msg.angle_increment;
    double distMin;
    distMin = laser_msg.ranges[minIndex];
    distFront = laser_msg.ranges[size/2];
    diffE = (distMin - wallDistance) - e;
    e = distMin - wallDistance;

    //preparing message
    geometry_msgs::Twist Twistmsg;
    Twistmsg.angular.z = direction*(p*e + d*diffE) + angleCoef * (angleMin - PI*direction/2);    //PD controller



    if (distFront < wallDistance){
        Twistmsg.linear.x = 0;
    }
    else if (distFront < wallDistance * 2){
        Twistmsg.linear.x = 0.5*maxSpeed;
    }
    else if (fabs(angleMin)>1.75){
        Twistmsg.linear.x = 0.4*maxSpeed;
    } 
    else {
        Twistmsg.linear.x = maxSpeed;
    }

    //publishing message
    pubMessage.publish(Twistmsg);
    ROS_INFO("Twistmsg got published on /cmd_vel topic");
}

void FollowWallAction::executeActionCB(const ros_auto_slam::FollowWallGoalConstPtr & goal){
    ROS_INFO("executeActionCB");
    tf::TransformListener tf_listener;
    tf::StampedTransform transform;
    try {
        ROS_INFO("transform stuff about to be done");
        tf_listener.waitForTransform("/odom","/base_link", ros::Time(0), ros::Duration(10.0) );
        tf_listener.lookupTransform("/odom","/base_link", ros::Time(0), transform);
        ROS_INFO("transform stuff done");
    } catch (tf::TransformException ex) {
        ROS_ERROR("%s",ex.what());
        ROS_INFO("TransformException ex");
    }
    while(goal->goal_position.x < 0 && goal->goal_position.x < 0){   //transform.getOrigin().x() && goal->goal_position.y != transform.getOrigin().y()){
                ROS_INFO("waiting for laser_msg");
        sensor_msgs::LaserScan laser_msg = *(ros::topic::waitForMessage<sensor_msgs::LaserScan>(SUBSCRIBER_TOPIC));
        FollowWallAction::executeScanCB(laser_msg); 
        tf_listener.lookupTransform("/map","/base_link", ros::Time(0),transform);
    }
    ROS_INFO("while finished");
    result.finished = true;
    as.setSucceeded(result);
}

int main(int argc, char *argv[])
{
    ros::init(argc, argv, "follow_wall");

    /*
    //-----------new begin
    ros::NodeHandle nh;
    actionlib::SimpleActionServer<ros_auto_slam::FollowWallAction> as;
    as(nh,"follow_wall", boost::bind(&FollowWallAction::executeActionCB, this, _1),false)
    //-----------new end
    */

    FollowWallAction follow_wall("follow_wall", WALL_DISTANCE, MAX_SPEED, DIRECTION, P, D, ANGLE_COEF);
    ROS_INFO("follow_wall action created. ros::spin() gets exectuted now...");
    ros::spin();    //wait for receiving action goal
    return 0;
}