#include "ros/ros.h"
#include "nav_msgs/GetMap.h"
#include "std_msgs/String.h"
#include "move_base_msgs/MoveBaseAction.h"
#include "move_base_msgs/MoveBaseGoal.h"
#include <actionlib/client/simple_action_client.h>
#include <ros_auto_slam/FollowWallAction.h>
#include "geometry_msgs/Point.h"
#include <tf/transform_listener.h>

#include <stdint.h>
#include <algorithm>
using namespace std;

#define MAX_FREE_CELL_VALUE 5   //a value close to 0 is considered as unoccupied cell



class MazeEntrance{
    public:
        int left_entrance_coordinate;
        int right_entrance_coordinate;

};