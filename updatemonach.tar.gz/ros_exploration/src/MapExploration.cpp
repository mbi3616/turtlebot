#include "ros/ros.h"
#include "nav_msgs/GetMap.h"
#include "std_msgs/String.h"


int main(int argc, char *argv[])
{
    ros::init(argc, argv, "map_explore");
    
    ros::NodeHandle nh;
    
    ros::ServiceClient client = nh.serviceClient<nav_msgs::GetMap>("nav_msgs/GetMap");

    nav_msgs::GetMap get_map_srv;

    if (client.call(get_map_srv))
    {
        ROS_INFO("Height: %ld", (long int)get_map_srv.response.map.info.height);
        ROS_INFO("Width: %ld", (long int)get_map_srv.response.map.info.width);
    }
    else
    {
        ROS_ERROR("Failed to call service nav_msgs/GetMap");
        return 1;
    }

    return 0;
}