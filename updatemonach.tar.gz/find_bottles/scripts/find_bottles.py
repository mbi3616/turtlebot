#!/usr/bin/env python
from __future__ import print_function

import roslib
#roslib.load_manifest('my_package')
import sys
import rospy
import cv2
import numpy as np
from std_msgs.msg import String
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from geometry_msgs.msg import Twist
import copy
PI = 3.1415926535897
CALIBRATE = True
USE_PICS = False
BEER = 1
WINE = 0
HAS_BORDER = False
WHITE_LINES_ABOVE = 30
MAX_ANG_VEL = 2

def nothing(x):
    pass


class image_converter:

    def __init__(self, bottle_type1, bottle_type2):
        
        self.wanted_bottle_1 = bottle_type1
        self.wanted_bottle_2 = bottle_type2
        self.bottle_1_pos = 0
        self.bottle_2_pos = 0
        self.focus_pos = -1

        self.cols = 0
        self.rows = 0
        self.left_border = 0
        self.right_border = 0
        self.center_pixel = 0   # stores the pixel color of the camera center 

        if USE_PICS:
            self.picture_number = 5
            name = "/home/turtlebot/catkin_ws/image" + str(self.picture_number) + ".png"
            self.cv_image = cv2.imread(name, 0)
            print("Pictures saved in catkin_ws are used ")
            self.workWithSaved()
        else:
            self.image_pub = rospy.Publisher("image_topic_2",Image,queue_size=10)
            self.twist_pub = rospy.Publisher("cmd_vel",Twist,queue_size=10)
            self.vel_msg = Twist()
            self.vel_msg.linear.x = 0
            self.vel_msg.linear.y = 0
            self.vel_msg.linear.z = 0 
            self.vel_msg.angular.x = 0
            self.vel_msg.angular.y = 0
            self.vel_msg.angular.z = 0 
            self.bridge = CvBridge()
            self.cv_image = None #cv2.imread("image5.png", 0)
            self.test_img = None
            self.image_sub = rospy.Subscriber("image_raw", Image, self.callback)
            self.is_centered = False    # turns true when the four bottles are in the center
            self.is_aimed = False   # turns true when a desired bottle is in the center of the picture
            self.is_reached = False# turns true when the one of the wanted bottles has been reached
            self.bottles_reached_cnt = 0

            #self.i = 1


    def callback(self, data):
        cv2.namedWindow("PixyCam")
        if CALIBRATE:
            cv2.createTrackbar("Threshold","PixyCam",40,255,nothing)
        try:
            self.cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            print(e)
        (self.rows,self.cols,channels) = self.cv_image.shape

        if not self.is_centered:
            print("rows: ", self.rows, "columns: ", self.cols)
        # rotation_matrix = cv2.getRotationMatrix2D((self.cols/2, self.rows/2), -90, 1)
        # self.cv_image = cv2.warpAffine(self.cv_image, rotation_matrix, (self.cols, self.rows))
        
        """
        name = "image" + picture_number + ".png"	#str(self.i)
        cv2.imwrite(name,self.cv_image) #save pics
        #if self.i >5:			
        #	self.i +=1
        """

        self.cv_image = cv2.cvtColor(self.cv_image, cv2.COLOR_BGR2GRAY)
        value = 40
        if CALIBRATE:
            value=cv2.getTrackbarPos("Threshold", "PixyCam")

        ret,self.cv_image = cv2.threshold(self.cv_image,value,255,cv2.THRESH_BINARY)
        cv2.imshow("PixyCam", self.cv_image)
        cv2.waitKey(100)	#time in ms
        """
        try:
            self.image_pub.publish(self.bridge.cv2_to_imgmsg(self.cv_image, "8UC1"))
        except CvBridgeError as e:
            print(e)
        """
       
        if not self.is_centered:    # if not centered
            if self.focus_pos == -1:    # if focus_pos not initialized yet
                self.test_img = copy.deepcopy(self.cv_image)
                c_begin_area, c_end_area = self.findBottleArea()    # calculates also the current focus_pos so this will be done once
            self.pan2Center()   # sets the angular velocity to pan to the center of the four bottles. if camera is centered robot will stop turning and sets self.is_centered to True
        else:   # if centered ...
            if self.bottle_1_pos == self.bottle_2_pos:    # if botttles haven't been typecasted yet (initially the position of the two wanted bottles are both the same)
                self.test_img = copy.deepcopy(self.cv_image)
                c_begin_area, c_end_area = self.findBottleArea()
                bottles = self.typecastBottles(c_begin_area, c_end_area) # returns the position of the bottle tops in the current picture. All four bottles need to be in sight
            else:   # bottles have been typecasted
                if not self.is_aimed:
                    turn_to_bottle()    # sets the angular velocity to pan to the desired bottle. if camera center is on the wanted bottle, the robot will stop turning and sets self.is_aimed to True
                else:   # bottle is aimed. Now robot needs to drive to the aimed bottle
                    if not self.is_reached:
                        self.drive2Bottle()
                    elif(self.bottles_reached_cnt<2): # if not both bottles have been reached...
                        # reset all for the next round
                        self.drive2Origin()
                        self.is_centered = False
                        self.is_aimed = False
                        self.is_reached = False
                        self.focus_pos = -1     # set to initial value



    def return2Origin(self):
        pass
    def drive2Bottle(self):
        """ sets self.is_reached to True if the bottle has been reached and it increases the self.bottles_reached_cnt by one"""
        self.vel_msg.linear.x = 0
        self.vel_msg.linear.y = 0
        self.vel_msg.linear.z = 0 
        self.vel_msg.angular.x = 0
        self.vel_msg.angular.y = 0
        self.vel_msg.angular.z = 0


        self.twist_pub.publish(vel_msg) # publish velocity msg

    def pan2Center(self):
        self.vel_msg.linear.x = 0
        self.vel_msg.linear.y = 0
        self.vel_msg.linear.z = 0 
        self.vel_msg.angular.x = 0
        self.vel_msg.angular.y = 0
        self.vel_msg.angular.z = 0

        #---update center_pixel and pocus_pos---
        new_center_pixel = self.cv_image(self.cols/2,0.65*self.rows)    # usually there is less reflection slightly below the center. Therefore the 0.65 factor
        if self.center_pixel and not new_center_pixel:  # if a color change of the center pixel from --WHITE2BLACK-- occured a focus_pos update is required
            if self.vel_msg.angular.z < 0:  # if robot is turning right --> focus_pos needs to bee INcreased
                self.focus_pos += 1
        elif not self.center_pixel and new_center_pixel:  # if a color change of the center pixel from --BLACK2WHITE-- occured a focus_pos update is required
            if self.vel_msg.angular.z > 0:  # if robot is turning left --> focus_pos needs to bee DEcreased
                self.focus_pos -= 1
        self.center_pixel = new_center_pixel    # update center pixel color

        #---set velocities:---
        if self.focus_pos == 2 and new_center_pixel:  # if the camera center is in the center of the four bottles 
            # fine adjustment:
            cnt_2_left = 0
            cnt_2_right = 0
            while(self.cv_image(self.cols/2-cnt_2_left,self.rows/2)):
                cnt_2_left +=1
            while(self.cv_image(self.cols/2+cnt_2_right,self.rows/2)):
                cnt_2_left +=1
            diff = cnt_2_left - cnt_2_right
            if abs(diff) > 5:
                if cnt_2_left > cnt_2_right:    # robot is slightly too much right
                    self.vel_msg.angular.z = 0.2*MAX_ANG_VEL
                else:    # robot is slightly too much left
                    self.vel_msg.angular.z = -0.2*MAX_ANG_VEL    
            else:   # centered good enough
                self.vel_msg.angular.z = 0
                self.is_centered = True
                print("Camera centered")                
        else:   # if the camera center is not yet in the middle of the four bottles:
            if self.focus_pos != 2:
                if self.focus_pos < 2:  # camera center is still too much left
                    self.vel_msg.angular.z = -MAX_ANG_VEL   # turn right
                elif self.focus_pos == 3 and not new_center_pixel:    # if the camera center is right on the 3. bottle
                    self.vel_msg.angular.z = MAX_ANG_VEL* 0.5
                else:   # focus_pos is bigger than 2: --> camera center is still too much right
                    self.vel_msg.angular.z = MAX_ANG_VEL    # turn left
            else:   # camera center is on the second bottle
                self.vel_msg.angular.z = -MAX_ANG_VEL*0.5
        self.twist_pub.publish(vel_msg) # publish message
    #------------END OF PAN2CENTER------------    
    def findBottomValue(self):
        #-----------FIND POSITION OF BOTTLE BOTTOM-----------
        black_cnt = 0
        bottom_pos = np.zeros(4)
        bottle_length = np.zeros(4)
        white_cnt = 0
        for bottle in range(0, 4):
            for r in range(int(bottles[bottle,0]), self.rows):
                if not self.cv_image.item(r,int(bottles[bottle,1])): #if black pixel
                    if white_cnt:
                        black_cnt += white_cnt
                        white_cnt = 0
                    black_cnt +=1
                else: # white pixel
                    white_cnt +=1
                    
                if white_cnt > 18:
                    break
            bottom_pos[bottle] = black_cnt + bottles[bottle,0]
            bottle_length[bottle] = black_cnt
            black_cnt = 0
            white_cnt = 0
        
        bottle_length_mean = int(np.mean(bottle_length))
        bottom_mean = int(np.mean(bottom_pos))
        print ("bottle_length_mean", bottle_length_mean)
        print ("bottom_mean", bottom_mean)
        r_measure = int(bottom_mean-0.35*bottle_length_mean)
        print ("r_measure", r_measure)
        #-----------END OF FIND POSITION OF BOTTLE BOTTOM-----------
    
    def findBottleArea(self):
        """findBottleArea returns c_begin_area, c_end_area, self.focus_pos"""
        #-----------FINDING BOTTLE AREA, BOTTLE WIDTHS CENTER POSITION-----------
        black_cnt = 0
        white_cnt = 0
        bottle_widths = np.zeros(4)
        bottle_cnt = -1
        first_detected = False
        first_white_cnt = 0
        big_white_right_gap = False
        r_measure = int(self.rows*0.65)
        self.draw_x(self.test_img, self.cols/2, r_measure, 3)
        c_begin_area = 0
        c_end_area = self.cols - 1

        for c in range(self.left_border,self.cols - self.right_border):    # loop through columns from left to right
            if self.cv_image.item(r_measure,c) and not first_detected:  #if black and no bottle detected yet
                first_white_cnt += 1
                continue
            if first_white_cnt < 15:    # asuming that before the first bottle a bigger white space will be detected
                first_white_cnt = 0
                continue
            else:   # meaning we have seen a big enough white space before the first bottle or we have detected some bottles already
                first_detected = True
            if not self.cv_image.item(r_measure,c): #if black pixel
                if white_cnt < 7 and black_cnt:  # if there are just a few white pixels since the last black pixel it"s probably only a reflection
                    black_cnt += white_cnt 
                elif white_cnt < 60:   # slightly bigger white gap means now a new bottle detected
                    if 35 > black_cnt > 12:
                        bottle_widths[bottle_cnt] = black_cnt # save width of prior bottle
                        if bottle_cnt == 3:
                            c_end_area = c - white_cnt
                        elif not bottle_cnt:
                            c_begin_area = c - black_cnt - white_cnt
                        bottle_cnt += 1
                        cv2.line(self.test_img, (c-white_cnt-black_cnt,self.rows-10), (c-white_cnt,self.rows-10), 0) 
                    black_cnt = 0
                else:   # very big gap detected: it probably means that no bottle is following anymore. 
                    c_end_area = c - white_cnt 
                    big_white_right_gap = True
                    break

                black_cnt += 1
                white_cnt = 0

            else:   #if white pixel
                white_cnt +=1

            if c == self.cols/2:
                self.center_pixel = self.cv_image.item(r_measure, c)    # update center pixel color
                self.focus_pos = bottle_cnt
                #cv2.circle(self.test_img, (self.cols/2, r_measure), 10, 0)
        
        if not self.center_pixel:
            print("The ", focus_pos, "Bottle is in the center of the picture")
        else:
            print("The ", focus_pos, ". space between the bottles is in the center of the picture")

        if bottle_cnt <= 3 and 35 > black_cnt > 12: # if nothing black is coming after the last bottle it is not saved yet: So it gets saved now in case a blob with the widht of a bottle has been detected before
            bottle_widths[bottle_cnt] = black_cnt
            c_end_area = c-white_cnt
            bottle_cnt += 1

        if bottle_cnt <=3:
            if big_white_right_gap:  #if not all four bottles have been detected and a big white gap on the right has been detected 
                self.focus_pos += 4 - bottle_cnt   # the focus_pos needs to be increased by the number of missing bottles
                #robot needs to turn right
            if first_white_cnt > 60:
                # robot needs to turn left
                pass

        bottle_width_mean = int(np.mean(bottle_widths))
        print("c_begin_area: ", c_begin_area, " = ", 100*c_begin_area/self.cols, "%")
        print("c_end_area: ", c_end_area, " = ", 100*c_end_area/self.cols, "%")
        cv2.line(self.test_img, (c_begin_area,0), (c_begin_area,self.rows-1), 0) 
        cv2.line(self.test_img, (c_end_area,0), (c_end_area,self.rows-1), 0) 
        print("bottle widths: ",bottle_widths)
        print("mean bottle width: ",bottle_width_mean)

        

        return c_begin_area, c_end_area
        #-----------END OF FINDING BOTTLE AREA, BOTTLE WIDTHS CENTER POSITION-----------
    
    def typecastBottles(self, c_begin_area, c_end_area):
        """self.bottle_1_pos and self.bottle_2_pos gets set"""
        #-----------TYPECASTING THE BOTTLES:-----------
        #all four bottles should be within sight at this time
        purely_white_cnt = 0
        bottle_cnt = 0
        bottles = np.zeros((4,2))

        cv2.imshow("turnToBottle", self.test_img)
        cv2.waitKey(3000)
        for r in range(0,self.rows):    # loop through pixels in a row
            black_detected = False
            for c in range(c_begin_area, c_end_area):    # loop through pixels in a column
                #print(self.cv_image.item(r,c))
                #print("c:", c, "r:", r)
                if not self.cv_image.item(r,c): # if black detected in this row
                    black_detected = True
                    if purely_white_cnt > WHITE_LINES_ABOVE: # if the prior n rows in the determined c_area were completely white it is likely that a black pixel is part of a bottle
                        if bottle_cnt == 4:
                            print("end for loop because 4 bottles have been detected already")
                            break
                        new_bottle = True
                        for b in range(0, bottle_cnt + 1):
                            #print("abs(c-bottles[", b, ",1])","abs(", c, "-",bottles[b,1],")=", abs(c-bottles[b,1]))
                            if abs(c-bottles[b,1]) < 20:  #same bottle as bottles[b] detected
                                new_bottle = False
                                break
                        if new_bottle:
                            if bottle_cnt < 2:
                                self.draw_x(self.test_img, c, r, 4, "WINE")
                            else: 
                                self.draw_x(self.test_img, c, r, 4, "BEER")
                            
                            bottles[bottle_cnt] = r,c
                            print(bottle_cnt + 1, ". bottle detected at c:",bottles[bottle_cnt,1], "r:", bottles[bottle_cnt,0] )
                            bottle_cnt += 1

            if bottle_cnt == 4:
                print("end for loop because 4 bottles have been detected already")
                break
            if not black_detected:
                purely_white_cnt += 1
            elif purely_white_cnt < WHITE_LINES_ABOVE:
                purely_white_cnt = 0
      
        bottle_order = np.argsort(bottles[:,1]) # returns the indices of bottles sorted by the c value in increasing order. bottle_order[x]: x:position, value: determines if beer(value>=2) or wine(value<2)
        print(bottle_order)
        print("From left to write we have the following order:")
        for x in range(0,4):
            if(bottle_order[x]<2):
                    print(x+1, ". WINE")
            else:
                    print(x+1, ". BEER")
        if self.wanted_bottle_1 != self.wanted_bottle_2:    # if we have to look for two different bottles...
            if self.wanted_bottle_1 == WINE:    # if wanted_bottle_1 = wine and wanted_bottle_2 = beer
                self.bottle_1_pos == np.argwhere(bottle_order == 0) + 1
                self.bottle_2_pos == np.argwhere(bottle_order == 3) + 1
            else:   # if wanted_bottle_1 = beer and wanted_bottle_2 = wine
                self.bottle_1_pos == np.argwhere(bottle_order == 3) + 1
                self.bottle_2_pos == np.argwhere(bottle_order == 0) + 1
        else:   # if both wanted bottles have the same type...
            if self.wanted_bottle_1 == WINE:    # if wanted_bottleS = WINE
                self.bottle_1_pos == np.argwhere(bottle_order == 0) + 1
                self.bottle_2_pos == np.argwhere(bottle_order == 1) + 1
            else:   # if wanted_bottleS = WINE
                self.bottle_1_pos == np.argwhere(bottle_order == 3) + 1
                self.bottle_2_pos == np.argwhere(bottle_order == 2) + 1

        print("Bottles have been identified. /n Now the roboter will turn to the first desired bottle.")

        return bottles
    #-----------END OF DETECTING THE BOTTLES:-----------

    def turn_to_bottle(self):
        self.vel_msg.linear.x = 0
        self.vel_msg.linear.y = 0
        self.vel_msg.linear.z = 0 
        self.vel_msg.angular.x = 0
        self.vel_msg.angular.y = 0
        self.vel_msg.angular.z = 0
        bottle_pos = 0
        if self.bottles_reached_cnt == 0:   # robot needs to turn to self.bottle_1_pos
            bottle_pos = self.bottle_1_pos
        elif self.bottles_reached_cnt == 1:   # robot needs to turn to self.bottle_2_pos
            bottle_pos = self.bottle_2_pos
        else:
            print("ERROR:   ----ROBOT DOESN'T KNOW WHER IT SHOULD TURN----")

        #---update center_pixel and focus_pos---
        new_center_pixel = self.cv_image(self.cols/2,0.65*self.rows)    # usually there is less reflection slightly below the center. Therefore the 0.65 factor
        if self.center_pixel and not new_center_pixel:  # if a color change of the center pixel from --WHITE2BLACK-- occured a focus_pos update is required
            if self.vel_msg.angular.z < 0:  # if robot is turning right --> focus_pos needs to bee INcreased
                self.focus_pos += 1
        elif not self.center_pixel and new_center_pixel:  # if a color change of the center pixel from --BLACK2WHITE-- occured a focus_pos update is required
            if self.vel_msg.angular.z > 0:  # if robot is turning left --> focus_pos needs to bee DEcreased
                self.focus_pos -= 1
        self.center_pixel = new_center_pixel    # update center pixel color


        #---set velocities:---

        if self.focus_pos == bottle_pos and not new_center_pixel:  # if the camera center is on the wanted bottle....
            # fine adjustment:
            cnt_2_left = 0
            cnt_2_right = 0
            while(not self.cv_image(self.cols/2-cnt_2_left,self.rows/2)):
                cnt_2_left +=1
            while(not self.cv_image(self.cols/2+cnt_2_right,self.rows/2)):
                cnt_2_left +=1
            diff = cnt_2_left - cnt_2_right
            if abs(diff) > 5:
                if cnt_2_left > cnt_2_right:    # robot is slightly too much right
                    self.vel_msg.angular.z = 0.2*MAX_ANG_VEL
                else:    # robot is slightly too much left
                    self.vel_msg.angular.z = -0.2*MAX_ANG_VEL    
            else:   # centered good enough
                self.vel_msg.angular.z = 0
                self.is_aimed = True
                print("Camera center is aiming the", self.bottles_reached_cnt + 1, ". wanted bottle")        
        else:   # if the camera center is not yet in the middle of the wanted bottles:
            if self.focus_pos == bottle_pos - 1 and new_center_pixel:    # camera focus is on the left side of the wanted bottle 
                self.vel_msg.angular.z = 0.5*MAX_ANG_VEL
            elif self.focus_pos == bottle_pos and new_center_pixel:      # camera focus is on the left right of the wanted bottle 
                self.vel_msg.angular.z = 0.5*MAX_ANG_VEL
            elif self.focus_pos > bottle_pos:    # if the camera center is still too much right
                self.vel_msg.angular.z = MAX_ANG_VEL
            else:   # bottle is too much left
                self.vel_msg.angular.z = -MAX_ANG_VEL
                        
        self.twist_pub.publish(vel_msg) # publish message
        return False

    #------------END OF TURNTOBOTTLE------------


    def workWithSaved(self):
        #use saved pics:
        name = "/home/turtlebot/catkin_ws/image" + str(self.picture_number) + ".png"	  #str(self.i)
        self.cv_image = cv2.imread(name, 0)
        self.rows, self.cols = self.cv_image.shape
        #self.cv_image = cv2.cvtColor(self.cv_image, COLOR_BGR2GRAY)
        value_old = 0
        value = 40
        ret,self.cv_image = cv2.threshold(self.cv_image,value,255,cv2.THRESH_BINARY)
        if CALIBRATE:
            cv2.createTrackbar("Threshold","PixyCam",40,255,nothing)
        #if self.i >5:			
        #	self.i +=1

        while True:
            value = cv2.getTrackbarPos("Threshold", "PixyCam")
            self.cv_image = cv2.imread(name, 0)
            if value != value_old:
                value_old = value
                print("Trackbar Pose:", value)
                ret,self.cv_image = cv2.threshold(self.cv_image,value,255,cv2.THRESH_BINARY)
                cv2.imshow("PixyCam", self.cv_image)
                cv2.waitKey(4000)	#time in ms
                self.turn_to_bottle()
            cv2.waitKey(500)	#time in ms
    #------------END OF WORKWITHSAVED------------

    def draw_x(self,img, col, row, size, text = None):
        cv2.line(img, (col-size,row-size), (col+size,row+size), 0) 
        cv2.line(img, (col-size,row+size), (col+size,row-size), 0)
        cv2.putText(img, text, (col-15,row-size), cv2.FONT_HERSHEY_SIMPLEX, 0.3, 40)   
        


def main(args):

    rospy.init_node('image_converter', anonymous=True)
    ic = image_converter(BEER, WINE)
    try:
        rospy.spin()
    except KeyboardInterrupt:
        print("Shutting down")
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main(sys.argv)
