#!/usr/bin/env python
from __future__ import print_function

import roslib
#roslib.load_manifest('my_package')
import sys
import rospy
import cv2
import numpy as np
from std_msgs.msg import String
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError

def nothing(x):
  pass



class image_converter:

  def __init__(self):
    self.image_pub = rospy.Publisher("image_topic_2",Image,queue_size=10)

    self.bridge = CvBridge()
    self.image_sub = rospy.Subscriber("image_raw",Image,self.callback)
    self.i = 1

  

  def callback(self,data):
    try:
      cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
    except CvBridgeError as e:
      print(e)

    (rows,cols,channels) = cv_image.shape
    
    rotation_matrix = cv2.getRotationMatrix2D((cols/2, rows/2), -90, 1)
    cv_image = cv2.warpAffine(cv_image, rotation_matrix, (cols, rows))
    name = "image" + str(self.i) + ".png"	
    if self.i >5:			
    	self.i +=1		

    #cv2.imwrite(name,cv_image)

    #if cols > 60 and rows > 60 :
    #  cv2.circle(cv_image, (50,50), 10, 255)
    cv_image1 = cv2.imread(name, 0)
    #cv_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)
    
    ret,binary50 = cv2.threshold(cv_image1,50,255,cv2.THRESH_BINARY)
    ret,binary60 = cv2.threshold(cv_image1,60,255,cv2.THRESH_BINARY)
    ret,binary70 = cv2.threshold(cv_image1,70,255,cv2.THRESH_BINARY)
    ret,binary80 = cv2.threshold(cv_image1,80,255,cv2.THRESH_BINARY)
    cv2.namedWindow('ValueAdjust')
    cv2.createTrackbar("Threshold","ValueAdjust",100,255,nothing)
    value=cv2.getTrackbarPos("Threshold", "ValueAdjust")
    ret,binary40 = cv2.threshold(cv_image1,value,255,cv2.THRESH_BINARY)




    cv2.imshow("ValueAdjust", binary40)
    cv2.imshow("binary50", binary50)
    cv2.imshow("binary60", binary60)
    cv2.imshow("binary70", binary70)
    cv2.imshow("binary80", binary80)
    cv2.waitKey(0)	#time in ms




    try:
      self.image_pub.publish(self.bridge.cv2_to_imgmsg(cv_image, "8UC1"))
    except CvBridgeError as e:
      print(e)

def main(args):
  ic = image_converter()
  rospy.init_node('image_converter', anonymous=True)
  try:
    rospy.spin()
  except KeyboardInterrupt:
    print("Shutting down")
  cv2.destroyAllWindows()

if __name__ == '__main__':
    main(sys.argv)
