#include <ros_auto_slam/map_explore.h>
bool simulation = false;



typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;
 
 class MapExploreAction
{
    protected:
        // Node handle declaration--
        ros::NodeHandle nh_;

        // Action server declaration
        actionlib::SimpleActionServer<ros_auto_slam::MapExploreAction> as_;

        // Use as action name
        std::string action_name_;

        // Declare the action result to Publish
        ros_auto_slam::MapExploreResult result_;


    public:
        // Initialize action server (Node handle, action name, action callback function)
        MapExploreAction(std::string name) : as_(nh_, name, boost::bind(&MapExploreAction::executeCB,
            this, _1), false), action_name_(name)
        {
            as_.start();
        }

        ~MapExploreAction(void)
        { }


        void findEntranceBoundary( char side, geometry_msgs::PointStamped &point_frame,  std::string frame_id, tf::TransformListener &tf_listener){
            sensor_msgs::LaserScan laser_msg = *(ros::topic::waitForMessage<sensor_msgs::LaserScan>("/scan"));

            double angle_inc = laser_msg.angle_increment;
            int size = laser_msg.ranges.size();
            double distance_front = laser_msg.ranges[0];
            double distance_x= distance_front;
            double distance_x_min = distance_front;
            double distance_min = distance_front;
            double distance;
            int i, i_x_min;
            switch (side){
                case 'l':
                    i=0;
                    ROS_INFO("distance_front - 0.1:  %f distance_x %f",  distance_front - 0.1,  distance_x);
                    for(; distance_front*0.95  <= distance_x && angle_inc*i<PI/3; i++){
                        distance = laser_msg.ranges[i];
                        if(std::isfinite(distance)){
                            if(distance_front>distance_x)  distance_front = distance_x;
                            distance_x = cos(angle_inc*i)*distance;
                            if(distance_x<distance_x_min){
                                distance_x_min= distance_x;
                                i_x_min = i;
                                distance_min = distance;
                            }
                            ROS_INFO("distance: %f distance_x: %f angle: %f  i: %d",distance, distance_x, angle_inc*i*180/PI, i);
                        }
                    }
                break;
                case 'r':
                    i=size-1;
                    ROS_INFO("distance_front - 0.1:  %f distance_x %f",  distance_front - 0.1,  distance_x);
                    for(; distance_front*0.95  <= distance_x && angle_inc*(size-i)<PI/3; i--){
                        distance = laser_msg.ranges[i];
                        if(std::isfinite(distance)){
                            if(distance_front>distance_x)  distance_front = distance_x;
                            distance_x = cos( angle_inc*(size-i))*distance;
                            if(distance_x<distance_x_min){
                                distance_x_min= distance_x;
                                i_x_min = i;
                                distance_min = distance;
                            }
                            ROS_INFO("distance: %f distance_x: %f angle: %f  i: %d",distance, distance_x, angle_inc*(size-i)*180/PI, i);
                        }
                    }
                break;
            }
            
            double distance_y = distance_min*sin(angle_inc*i_x_min);
            geometry_msgs::PointStamped point_scan;
            point_scan.header.frame_id = "/base_scan";
            point_scan.point.x = distance_x_min;
            point_scan.point.y = distance_y;
            ROS_INFO("point_scan: x %f y %f angle: %f  i: %d", point_scan.point.x, point_scan.point.y, angle_inc*i*180/PI, i);
            tf_listener.transformPoint(frame_id, point_scan, point_frame); 
            ROS_INFO("point_frame: x %f y %f angle: %f  i: %d", point_frame.point.x, point_frame.point.y, angle_inc*i*180/PI, i);
        }


        // A function that receives an action goal message and performs a specified
        // action.
        void executeCB(const ros_auto_slam::MapExploreGoalConstPtr &goal)
        {
            //ros::Rate r(1);     // Loop Rate: 0.2Hz -> 5 Sek.

            // Used as a variable to store the success or failure of an action
            // Setting Fibonacci sequence initialization,
            // add first (0) and second message (1) of feedback.
            //feedback_.sequence.clear();
            //feedback_.sequence.push_back(0);
            //feedback_.sequence.push_back(1);

            ROS_INFO("%s: Executing, creating Labyrinth Map");
            // Action content


            /*
            while(exploring)
            {
                // Confirm action cancellation from action client
                if (as_.isPreemptRequested() || !ros::ok())
                {
                    // Notify action cancellation
                    ROS_INFO("%s: Preempted", action_name_.c_str());
                    as_.setPreempted();
                    // Action cancellation
                    exploring = false;
                    // Consider action as failure and save to variable
                    break;
                }

                // Store the sum of current Fibonacci number and the previous number in the feedback
                // while there is no action cancellation or the action target value is reached.
                //feedback_.sequence.push_back(feedback_.sequence[i] + feedback_.sequence[i-1]);
                //as_.publishFeedback(feedback_);
                // Publish feedback
                r.sleep();
                // sleep according to the defined loop rate.
            }
            */


            // MoveBaseAction Client
            ROS_INFO("ros::init in map_explore done");
            actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> ac_move_base("move_base", true); 
            while(!ac_move_base.waitForServer(ros::Duration(5.0))){
                ROS_INFO("Waiting for the move_base action server to come up");
            }
            
            move_base_msgs::MoveBaseGoal mb_goal;
            geometry_msgs::PointStamped point_left_entrance, point_right_entrance;

            if(simulation){
                tf::TransformListener tf_listener;
                tf::StampedTransform transform;
                ROS_INFO("tf stuff");
                try {
                    tf_listener.waitForTransform("/odom","/base_link", ros::Time(0), ros::Duration(10.0) );
                    tf_listener.lookupTransform("/odom","/base_link", ros::Time(0), transform);
                } catch (tf::TransformException ex) {
                    ROS_ERROR("%s",ex.what());
                }

                //tf_listener.lookupTransform("odom","base_link", ros::Time(0),transform);


                findEntranceBoundary('l',point_left_entrance, "/odom", tf_listener);
                findEntranceBoundary('r',point_right_entrance, "/odom", tf_listener);

            

                mb_goal.target_pose.header.frame_id = "odom";
                mb_goal.target_pose.header.stamp = ros::Time::now();

                mb_goal.target_pose.pose.position.x = point_left_entrance.point.x - TURTLE_RADIUS - 0.15;
                mb_goal.target_pose.pose.position.y = point_left_entrance.point.y + 0.20;
                mb_goal.target_pose.pose.orientation.z = 1;

                ROS_INFO("Sending mb_goal x=%f y=%f ", mb_goal.target_pose.pose.position.x, mb_goal.target_pose.pose.position.y);
                ac_move_base.sendGoal(mb_goal);
                ac_move_base.waitForResult();
                //ros::Duration(3).sleep(); // sleep 
                sensor_msgs::LaserScan laser_msg = *(ros::topic::waitForMessage<sensor_msgs::LaserScan>("/scan"));
                if(laser_msg.ranges[(int)laser_msg.ranges.size()/4] > 0.3){
                    mb_goal.target_pose.header.frame_id = "base_link";
                    mb_goal.target_pose.pose.position.x = 0;
                    mb_goal.target_pose.pose.position.y = 0.2;
                    mb_goal.target_pose.pose.orientation.w = 0.707;
                    mb_goal.target_pose.pose.orientation.z = 0.707;
                    ac_move_base.sendGoal(mb_goal);
                    ac_move_base.waitForResult();
                    //ros::Duration(3).sleep(); // sleep 
                }
            }else{#include "ros/ros.h"
#include "std_msgs/String.h"
#include "std_msgs/Float64.h"
#include "move_base_msgs/MoveBaseAction.h"
#include "move_base_msgs/MoveBaseGoal.h"
#include <actionlib/client/simple_action_client.h>
#include <ros_auto_slam/FollowWallAction.h>
#include <ros_auto_slam/ExploreRemainderAction.h>
#include "sensor_msgs/LaserScan.h"
#include "geometry_msgs/Point.h"
#include "geometry_msgs/PointStamped.h"
#include <tf/transform_listener.h>

#include <actionlib/server/simple_action_server.h>
#include <ros_auto_slam/MapExploreAction.h>

#include <stdint.h>
#include <algorithm>
#include <cmath>
                mb_goal.target_pose.header.frame_id = "base_link";
                mb_goal.target_pose.pose.position.x = 0.3;
                mb_goal.target_pose.pose.position.y = 0;
                mb_goal.target_pose.pose.orientation.w = 1;
                mb_goal.target_pose.pose.orientation.z = 0;
                ac_move_base.sendGoal(mb_goal);
                ac_move_base.waitForResult();
                ROS_INFO("30cm forward in x direction...");
                ros::Duration(4).sleep(); // sleep 
                sensor_msgs::LaserScan laser_msg = *(ros::topic::waitForMessage<sensor_msgs::LaserScan>("/scan"));
                double dist_left = laser_msg.ranges[(int)laser_msg.ranges.size()/4];
                if(dist_left > 0.3){
                    ROS_INFO("no wall on the left within 30cm");
                    mb_goal.target_pose.pose.position.x = 0;
                    if(dist_left>0.8){
                        mb_goal.target_pose.pose.position.y = 0.6;
                    }else{
                        mb_goal.target_pose.pose.position.y = dist_left - 0.2;
                    }
                    mb_goal.target_pose.pose.orientation.w = 0.707;
                    mb_goal.target_pose.pose.orientation.z = 0.707;
                    ac_move_base.sendGoal(mb_goal);
                    ac_move_base.waitForResult();
                    ROS_INFO("align to wall in y direction...");
                    ros::Duration(4).sleep(); // sleep 
                    //ros::Duration(3).sleep(); // sleep 
                }
                point_left_entrance.point.x = 0;
                point_right_entrance.point.x = 0;
                point_left_entrance.point.y = -8;
                point_right_entrance.point.y = 8;
            }   //end else
                        
            //system("rosrun ros_auto_slam follow_wall_node");
            //ROS_INFO("rosrun ros_auto_slam follow_wall_node gets executed");



            //ROS_INFO("tf stuff ended /n next is actionlib::SimpleActionClient<ros_auto_slam::FollowWallAction> ac_follow_wall");
            
            actionlib::SimpleActionClient<ros_auto_slam::FollowWallAction> ac_follow_wall("follow_wall", true);
            ros_auto_slam::FollowWallGoal fw_goal;

            fw_goal.y_left = 8;
            fw_goal.y_right = -8;
            fw_goal.x = 0;  
            /*
            fw_goal.y_left = point_left_entrance.point.y;
            fw_goal.y_right = point_right_entrance.point.y;
            fw_goal.x = point_right_entrance.point.x;  
            */


            ROS_INFO("fw_goal: x=%f y_left=%f y_right=%f",fw_goal.x, fw_goal.y_left, fw_goal.y_right);
            ac_follow_wall.waitForServer();
            ac_follow_wall.sendGoal(fw_goal);
            

            bool finished_before_timeout = ac_follow_wall.waitForResult(ros::Duration(400.0));
            if(finished_before_timeout){
                ROS_INFO("Robot should be at the starting position again.");
                ROS_INFO("Explore Remainder Action goal gets send now");
                ros_auto_slam::FollowWallResult fw_result = *(ac_follow_wall.getResult()); 
                ROS_INFO("xmin:%f xmax:%f ymin:%F ymax:%f",fw_result.xmin, fw_result.xmax, fw_result.ymin, fw_result.ymax);

                actionlib::SimpleActionClient<ros_auto_slam::ExploreRemainderAction> ac_explore_remainder("explore_remainder", true);
                ros_auto_slam::ExploreRemainderGoal er_goal;
                er_goal.x_min = fw_result.xmin;
                er_goal.x_max = fw_result.xmax;
                er_goal.y_min = fw_result.ymin;
                er_goal.y_max = fw_result.ymax;

                ac_explore_remainder.waitForServer();
                ac_explore_remainder.sendGoal(er_goal);
                finished_before_timeout = ac_explore_remainder.waitForResult(ros::Duration(300.0));
                if(finished_before_timeout){
                    ROS_INFO("Map is completed. And could be saved now.");
                    //system("rosrun map_server map_saver -f unedited_map");
                    result_.done = true;
                    ROS_INFO("%s: Succeeded", action_name_.c_str());
                    as_.setSucceeded(result_);
                }
            }

            // system("rosnode kill /turtlebot3_slam_gmapping");
            // system("roslaunch turtlebot3_slam turtlebot3_slam.launch slam_methods:=gmapping");
        }
};



//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX




int main(int argc, char *argv[])
{
    ros::init(argc, argv, "map_explore");    
    ros::NodeHandle nh;

    MapExploreAction map_explore("map_explore");
    ros::spin();    //wait for receiving action goal

    return 0;
}
    

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
//------------------------------  XX  ------------------------------





/*
    if (get_map_client.call(get_map_srv))
    {
        if (!inside_labyrinth){
            // get x value of front labyrinth wall:
            

            // drive inside labyrinth:
            inside_labyrinth = true;

            // restart slam:
    //      system("rosnode kill /turtlebot3_slam_gmapping");
    //        system("roslaunch turtlebot3_slam turtlebot3_slam.launch slam_methods:=gmapping");

        }

*/
/*
        int height = get_map_srv.response.map.info.height;
        int width = get_map_srv.response.map.info.width;
       
        ROS_INFO("Height: %ld", (long int)get_map_srv.response.map.info.height);
        ROS_INFO("Width: %ld", (long int)get_map_srv.response.map.info.width);
        
        int8_t occupancy_grid_2d [height][width] = {0};
        int8_t occupancy_grid_1d[height*width];
        int8_t new_goal_grid [height][width] = {0};     // this grid is for showing where a transition from an unoccupied to an unknown cell is

        copy(get_map_srv.response.map.data.begin(),get_map_srv.response.map.data.end(),occupancy_grid_1d);

        //creating 2D Occupancy Grid
        for(int row = 0; row < height; row++){
            copy(occupancy_grid_1d + width*row, occupancy_grid_1d + width*(row+1), occupancy_grid_2d[row]);
        }
        
        ROS_INFO("2D Occupancy Grid was created");


*/
        /*
        ROS_INFO("!!!!!!!!!!!!!<<<Checkpoint --1-- >>>!!!!!!!!!!!!!!!");
        
        //-------------evaluate transition pixels from unocuppied cell to unknown cell:-----------------
        //find horizontal transition pixels:
        bool previous_cell_unknown;
        (occupancy_grid_2d[0][0]==-1) ? (previous_cell_unknown = true) : (previous_cell_unknown = false);
        for(int row = 0; row < height; row++){
            for(int col = 0; col < width; col++){

                if(occupancy_grid_2d[row][col]==-1){
                    previous_cell_unknown = true;
                    continue;       
                }
                else{
                    
                    if(previous_cell_unknown && occupancy_grid_2d[row][col] < MAX_FREE_CELL_VALUE){
                        // horizontal transition found
                        new_goal_grid[row][col]=100;    // so if a cell has the value 100 it means its free and its left neighbour is unknown
                    }
                    previous_cell_unknown = false;
                }  
            }
        }

        //find vertical transition pixels:
        (occupancy_grid_2d[0][0]==-1) ? (previous_cell_unknown = true) : (previous_cell_unknown = false);
        for(int col = 0; col < width; col++){
            for(int row = 0; row < height; row++){

                if(occupancy_grid_2d[row][col]==-1){
                    previous_cell_unknown = true;
                    continue;       
                }
                else{
                    
                    if(previous_cell_unknown && occupancy_grid_2d[row][col] < MAX_FREE_CELL_VALUE){
                        // vertical transition found
                        new_goal_grid[row][col]=100;    // so if a cell has the value 100 it means its free and its left neighbour is unknown
                    }
                    previous_cell_unknown = false;
                }  
            }
        }
        }else
        {
            ROS_ERROR("Failed to call service nav_msgs/GetMap");
            return 1;
        }



        /*-----------------------calculate next goal position------------------------------*/


        /************************move to next goal position**************************/
/*
        //wait for the action server to come up
        while(!ac_move_base.waitForServer(ros::Duration(5.0))){
        ROS_INFO("Waiting for the move_base action server to come up");
        }
        
        move_base_msgs::MoveBaseGoal goal;

        //we'll send a goal to the robot to move 1 meter forward
        goal.target_pose.header.frame_id = "base_link";
        goal.target_pose.header.stamp = ros::Time::now();

        goal.target_pose.pose.position.x = 1.0;
        goal.target_pose.pose.orientation.w = 1.0;

        ROS_INFO("Sending goal");
        ac_move_base.sendGoal(goal);

        ac_move_base.waitForResult();

        if(ac_move_base.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
            ROS_INFO("Hooray, the base movedto our goal");
        else
            ROS_INFO("The base failed to move to our goal");
        */



//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX





/*
#include <ros/ros.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <actionlib/client/simple_action_client.h>
#include <nav_msgs/OccupancyGrid.h>


typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;
 
class MapExploreAction
{
protected:
    // Node handle declaration--
    ros::NodeHandle nh_;

    // Action server declaration
    actionlib::SimpleActionServer<ros_auto_slam::MapExploreAction> as_;

    // Use as action name
    std::string action_name_;

    // Declare the action result to Publish
    ros_auto_slam::FibonacciResult result_;


public:
    // Initialize action server (Node handle, action name, action callback function)
    MapExploreAction(std::string name) : as_(nh_, name, boost::bind(&MapExploreAction::executeCB,
        this, _1), false), action_name_(name)
    {
      as_.start();
    }

    ~MapExploreAction(void)
    {
    }

    // A function that receives an action goal message and performs a specified
    // action.
    void executeCB(const ros_auto_slam::MapExploreActionGoalConstPtr &goal)
    {
      ros::Rate r(0.2);
      // Loop Rate: 0.2Hz -> 5 Sek.

      bool searching = true;

      // Used as a variable to store the success or failure of an action
      // Setting Fibonacci sequence initialization,
      // add first (0) and second message (1) of feedback.
      //feedback_.sequence.clear();
      //feedback_.sequence.push_back(0);
      //feedback_.sequence.push_back(1);

      ROS_INFO("%s: Executing, creating Labyrinth Map");
      // Action content

      while(searching)
      {
          // Confirm action cancellation from action client
          if (as_.isPreemptRequested() || !ros::ok())
          {
              // Notify action cancellation
              ROS_INFO("%s: Preempted", action_name_.c_str());
              as_.setPreempted();
              // Action cancellation
              searching = false;
              // Consider action as failure and save to variable
              break;
          }

          // Store the sum of current Fibonacci number and the previous number in the feedback
          // while there is no action cancellation or the action target value is reached.
          //feedback_.sequence.push_back(feedback_.sequence[i] + feedback_.sequence[i-1]);
          //as_.publishFeedback(feedback_);
          // Publish feedback
          r.sleep();
          // sleep according to the defined loop rate.
      }
      //If no more undetected fields
      if(success)
      {
          result_.sequence = true;
          ROS_INFO("%s: Succeeded", action_name_.c_str());
          as_.setSucceeded(result_);
      }
    }
};

int main(int argc, char** argv){
    ros::init(argc, argv, "action_server");
    // Initializes Node Name
    // Fibonacci Declaration(Action Name: ros_tutorial_action)
    FibonacciAction fibonacci("ros_tutorial_action");
    ros::spin();
    // Wait to receive action goal
    return 0;
}


int main(int argc, char** argv){
	// "map_explore" --> Nodename
	ros::init(argc, argv, "map_explore"); 
 
	//tell the action client that we want to spin a thread by default
	MoveBaseClient ac("move_base", true);

	//wait for the action server to come up
	while(!ac.waitForServer(ros::Duration(5.0))){
		ROS_INFO("Waiting for the move_base action server to come up");
	}
 
	move_base_msgs::MoveBaseGoal goal;
 
        //"base_link" is the coordinate system of the robot
	goal.target_pose.header.frame_id = "base_link";
	goal.target_pose.header.stamp = ros::Time::now();
 
	goal.target_pose.pose.position.x = 1.0;
	goal.target_pose.pose.orientation.w = 1.0;
 
        ROS_INFO("Sending goal");
	ac.sendGoal(goal);
 
	ac.waitForResult();
 
	if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
		ROS_INFO("Hooray, the base moved 1 meter forward");
	else
		ROS_INFO("The base failed to move forward 1 meter for some reason");
 
	return 0;
}
*/