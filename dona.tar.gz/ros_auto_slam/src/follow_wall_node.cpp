//#include "ros_auto_slam/follow_wall_node.h"
#include <ros/ros.h>
#include <actionlib/server/simple_action_server.h>
#include <ros_auto_slam/FollowWallAction.h>
#include "sensor_msgs/LaserScan.h"
#include "geometry_msgs/Twist.h"
#include "geometry_msgs/Point.h"
#include <tf/transform_listener.h>
#include <math.h>
#include "std_msgs/Float64.h"

#define PI 3.141592
#define SUBSCRIBER_BUFFER_SIZE 1  // Size of buffer for subscriber.
#define PUBLISHER_BUFFER_SIZE 1000  // Size of buffer for publisher.
#define WALL_DISTANCE 0.2
#define MAX_SPEED 0.2
#define P 6     // Proportional constant for controller
#define D 3    // Derivative constant for controller
#define ANGLE_COEF 0.9   // Proportional constant for angle controller
//#define DIRECTION -1 // 1 for wall on the right side of the robot (-1 for the left side).
// #define PUBLISHER_TOPIC "/syros/base_cmd_vel"
#define PUBLISHER_TOPIC "/cmd_vel"
// #define SUBSCRIBER_TOPIC "/syros/laser_laser"
//#define SUBSCRIBER_TOPIC "/base_scan"
#define SUBSCRIBER_TOPIC "/scan"



class FollowWallAction{
    public:
        //variables
        double wallDistance;    // Desired distance from the wall.
        double e;               // Difference between desired distance from the wall and actual distance.
        double diffE;           // Derivative element for PD controller;
        double maxSpeed;        // Maximum speed of robot.
        double p;               // k_P Constant for PD controller.
        double d;               // k_D Constant for PD controller.
        double angleCoef;       // Coefficient for P controller.
        //int direction;          // 1 for wall on the right side of the robot (-1 for the left one).
        double angleMin;        // Angle, at which was measured the shortest distance.
        double distFront;       // Distance, measured by ranger in front of robot.
        ros::Publisher pubMessage;  // Object for publishing messages.

        ros::NodeHandle nh;
        actionlib::SimpleActionServer<ros_auto_slam::FollowWallAction> as;
        std::string action_name;

        ros_auto_slam::FollowWallFeedback feedback;
        ros_auto_slam::FollowWallResult result;
        
        FollowWallAction(std::string name, double wallDist, double maxSp, double pr, double di, double an) : 
        as(nh,name, boost::bind(&FollowWallAction::executeActionCB, this, _1),false){
            action_name = name;
            wallDistance = wallDist;
            maxSpeed = maxSp;
            //direction = dir;
            p = pr;
            d = di;
            angleCoef = an; 
            e = 0;
            angleMin = 0;  //angle, at which was measured the shortest distance
            pubMessage = nh.advertise<geometry_msgs::Twist>("/cmd_vel", 1000);
            as.start();
            ROS_INFO("as.start() got executed");
        }

        ~FollowWallAction(void){}

        void executeActionCB(const ros_auto_slam::FollowWallGoalConstPtr & goal);
        void executeScanCB(const sensor_msgs::LaserScan msg);
};

void FollowWallAction::executeScanCB(const sensor_msgs::LaserScan laser_msg){
     //ROS_INFO("FollowWallAction::executeScanCB");
     int size = laser_msg.ranges.size();

    //Variables whith index of highest and lowest value in array.
    int minIndex;       // direction -1: front, direction 1: back
    int maxIndex;  // direction -1: back,  direction 1: front


    if(laser_msg.ranges[(int)size/4] < 1.2*wallDistance && laser_msg.ranges[0] < 1.2*wallDistance){
        minIndex = 0;     //30degrees  
        maxIndex = (int)size/12; 
                ROS_INFO("0 to 30");
    }else if(laser_msg.ranges[(int)size/4] < 2*wallDistance){
        minIndex = 0;       
        maxIndex = (int)size/2;
        ROS_INFO("...");
    }else{
        minIndex = (int)size/12;     //30degrees  
        maxIndex = (int)size/2;
        ROS_INFO("30 to 180");
    }
   
   //This cycle goes through array and finds minimum
    for(int i = minIndex; i < maxIndex; i++)    //going from back to the front in counter clockwise direction
    {
        if (laser_msg.ranges[i] < laser_msg.ranges[minIndex] && laser_msg.ranges[i] > 0.0){
            minIndex = i;
        }           
    }

    //ROS_INFO("minIndex = %d maxIndex = %d size = %d", minIndex, maxIndex, size);

    //Calculation of angles from indexes and storing data to class variables.
    angleMin = (minIndex)*laser_msg.angle_increment; 
    double distMin;
    distMin = laser_msg.ranges[minIndex];
    distFront = laser_msg.ranges[0];
    diffE = (distMin - wallDistance) - e;
    e = distMin - wallDistance;
    //ROS_INFO("angleMin = %f distMin = %f distFront = %f e = %f", angleMin, distMin, distFront, e);

    //preparing message
    geometry_msgs::Twist Twistmsg;

    Twistmsg.angular.z = p*e + d*diffE + angleCoef * (angleMin - PI/2);    //PD controller The z value is rad/s in counterclockwise dir.
    
    if(Twistmsg.angular.z > 2){
        ROS_INFO("z= %f rad/s", Twistmsg.angular.z);
        ROS_INFO("z = %f  + %f  +  %f", p*e, d*diffE, angleCoef*(angleMin - PI/2));
        ROS_INFO("e:%f  diffE:%f  +  anglediff:%f", e, diffE, (angleMin - PI/2));
    }
    //ROS_INFO("angular.z %f", Twistmsg.angular.z);
    
    if(laser_msg.ranges[(int)size/3.6]> 3*wallDistance){
        //ROS_INFO("1: dist[100deg]: %f", laser_msg.ranges[(int)size/3.6]);
        Twistmsg.linear.x = 0.4*maxSpeed;
    }
    else if(laser_msg.ranges[(int)size/4.5]>3*wallDistance){
        Twistmsg.linear.x = 0.3*maxSpeed;
    }
    else if (distFront < wallDistance * 2){
        //ROS_INFO("distFront < 2x wallDistance");
        if (distFront < wallDistance){
            //ROS_INFO("distFront < wallDistance");
            Twistmsg.linear.x = 0;
        }else{
            Twistmsg.linear.x = 0.5*maxSpeed;
        }

    }
    else if (fabs(angleMin)>1.75){
        //ROS_INFO("4: angleMin >100deg");
        Twistmsg.linear.x = 0.2*maxSpeed;
    } 
    else {
        Twistmsg.linear.x = maxSpeed;
    }

    //publishing message
    pubMessage.publish(Twistmsg);
    //ROS_INFO("Twistmsg got published on /cmd_vel topic");
}

void FollowWallAction::executeActionCB(const ros_auto_slam::FollowWallGoalConstPtr & goal){
    //ROS_INFO("executeActionCB");
    result.xmax = 0;
    result.ymin = 0;
    result.ymax = 0;

    tf::TransformListener tf_listener;
    tf::StampedTransform transform;
    try {
        tf_listener.waitForTransform("/map","/base_link", ros::Time(0), ros::Duration(10.0) );
        tf_listener.lookupTransform("/map","/base_link", ros::Time(0), transform);
    } catch (tf::TransformException ex) {
        ROS_ERROR("%s",ex.what());
    }
    ROS_INFO("cur_x=%f cur_y=%f",transform.getOrigin().x(), transform.getOrigin().y());
    //while(!(goal->x < transform.getOrigin().x() && goal->y_right > transform.getOrigin().y() && goal->y_left<transform.getOrigin().y())){   // simulation
   while(goal->x < 0.1+transform.getOrigin().x()){    // real world
        try {
            tf_listener.waitForTransform("/map","/base_link", ros::Time(0), ros::Duration(1.0) );
            tf_listener.lookupTransform("/map","/base_link", ros::Time(0), transform);
        } catch (tf::TransformException ex) {
            ROS_ERROR("%s",ex.what());
        }
        if(transform.getOrigin().x() > result.xmax){
            result.xmax = transform.getOrigin().x();
        }
        if(transform.getOrigin().y() > result.ymax){
            result.ymax = transform.getOrigin().y();
        }else if(transform.getOrigin().y() < result.ymin){
            result.ymin = transform.getOrigin().y();
        }

        sensor_msgs::LaserScan laser_msg = *(ros::topic::waitForMessage<sensor_msgs::LaserScan>(SUBSCRIBER_TOPIC));
        FollowWallAction::executeScanCB(laser_msg); 
        //tf_listener.lookupTransform("/map","/base_link", ros::Time(0),transform);
    }

    geometry_msgs::Twist Twistmsg;
    Twistmsg.linear.x = 0;
    Twistmsg.angular.z = 0;
    pubMessage.publish(Twistmsg);
    ROS_INFO("cur_x=%f cur_y=%f",transform.getOrigin().x(), transform.getOrigin().y());
    ROS_INFO("goalx=%f goaly=%f - %f",goal->x, goal->y_right, goal->y_left);
    ROS_INFO("while finished");
    result.xmin = -0.3;
    result.xmax += 0.3;
    result.ymin -= 0.3;
    result.ymax += 0.3;
    as.setSucceeded(result);
}

int main(int argc, char *argv[])
{
    ros::init(argc, argv, "follow_wall");
    /*
    //-----------new begin
    ros::NodeHandle nh;
    actionlib::SimpleActionServer<ros_auto_slam::FollowWallAction> as;
    as(nh,"follow_wall", boost::bind(&FollowWallAction::executeActionCB, this, _1),false)
    //-----------new end
    */
    FollowWallAction follow_wall("follow_wall", WALL_DISTANCE, MAX_SPEED, P, D, ANGLE_COEF);
    ROS_INFO("follow_wall action created. ros::spin() gets exectuted now...");
    ros::spin();    //wait for receiving action goal
    return 0;
}