#!/usr/bin/env python
from __future__ import print_function

import roslib
#roslib.load_manifest('my_package')
import sys
import rospy
import actionlib
import find_bottles.msg

import cv2
import numpy as np
from std_msgs.msg import String
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from geometry_msgs.msg import Twist

import copy
PI = 3.1415926535897
CALIBRATE = True
USE_PICS = False
BEER = 1
WINE = 0
HAS_BORDER = False
WHITE_LINES_ABOVE = 30.0
MAX_ANG_VEL = 0.02
MAX_LIN_VEL = 0.06
THRESHOLD = 60
BLACK_CNT_MAX = 37  #max width of a bottle in pixel when robot is at the origin
BLACK_CNT_MIN = 10  #max width of a bottle in pixel when robot is at the origin
CAM_UPDATE_TIME = 100   # in ms

def nothing(x):
    pass


class FindBottlesAction(object):

    _feedback = find_bottles.msg.FindBottlesFeedback()
    _result = find_bottles.msg.FindBottlesResult()

    def __init__(self, name):
        
        self._action_name = name
        self._as = actionlib.SimpleActionServer(self._action_name, find_bottles.msg.FindBottlesAction, execute_cb=self.execute_cb, auto_start = False)
        self._as.start()

        self.wanted_bottle_1 = 0
        self.wanted_bottle_2 = 0
        self.bottle_1_pos = 0
        self.bottle_2_pos = 0
        self.focus_pos = -1
        self.cols = 0
        self.rows = 0
        self.left_border = 0
        self.right_border = 0
        
        self.all_purpose_cnt = 0
        self.same_color_cnt = 0
        self.center_pixel = 0   # stores the pixel color of the camera center 
        self.prev_blob_color = -1
        self.blob_color = -1

        if USE_PICS:
            self.picture_number = 5
            name = "/home/turtlebot/catkin_ws/image" + str(self.picture_number) + ".png"
            self.cv_image = cv2.imread(name, 0)
            print("Pictures saved in catkin_ws are used ")
            self.workWithSaved()
        else:
            #self.image_pub = rospy.Publisher("image_topic_2",Image,queue_size=10)
            self.twist_pub = rospy.Publisher("cmd_vel",Twist,queue_size=0)
            self.vel_msg = Twist()
            self.vel_msg.linear.x = 0
            self.vel_msg.linear.y = 0
            self.vel_msg.linear.z = 0 
            self.vel_msg.angular.x = 0
            self.vel_msg.angular.y = 0
            self.vel_msg.angular.z = 0 
            self.bridge = CvBridge()
            self.cv_image = None #cv2.imread("image5.png", 0)
            self.test_img = None
            self.center_pixel = 0   # stores the pixel color of the camera center one
            self.image_sub = None #rospy.Subscriber("image_raw", Image, self.callback)
            self.is_centered = False    # turns true when the four bottles are in the center
            self.is_aimed = False   # turns true when a desired bottle is in the center of the picture
            self.is_reached = False# turns true when the one of the wanted bottles has been reached
            self.bottles_reached_cnt = 0

            #self.i = 1
    #----------------- END __INIT__ ---------------------
    def execute_cb(self, goal):
        # helper variables
        r = rospy.Rate(1)
        success = True
        self.wanted_bottle_1 = goal.first_bottle
        self.wanted_bottle_2 = goal.second_bottle
        feedback_sent = False
        self._result.done = False
        self.image_sub = rospy.Subscriber("image_raw", Image, self.callback)

        while not self._result.done:
            # check that preempt has not been requested by the client
            if self._as.is_preempt_requested():
                rospy.loginfo('%s: Preempted' % self._action_name)
                self._as.set_preempted()
                success = False
                break

            # publish the feedback
            if self._feedback.first_reached and not feedback_sent:
                self._as.publish_feedback(self._feedback)
                feedback_sent = True
            r.sleep()

        if success:
            print("XXXXXXXXXXXXXXXXXXXXXXXXX")
            print(self._action_name, "  S U C C E E D E D")
            print("XXXXXXXXXXXXXXXXXXXXXXXXX")
            self._as.set_succeeded(self._result)
        self.vel_msg.linear.x = 0
        self.vel_msg.angular.z = 0
        self.twist_pub.publish(self.vel_msg)
        cv2.destroyAllWindows()
        print("Good Bye")
        rospy.signal_shutdown('Quit')
     
    #----------------- END EXECUTE_CB --------------------
    def callback(self, data):
        cv2.namedWindow("PixyCam")
        if CALIBRATE:
            cv2.createTrackbar("Threshold","PixyCam",THRESHOLD,255,nothing)
        try:
            self.cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            print(e)
        (self.rows,self.cols,channels) = self.cv_image.shape


        # rotation_matrix = cv2.getRotationMatrix2D((self.cols/2, self.rows/2), -90, 1)
        # self.cv_image = cv2.warpAffine(self.cv_image, rotation_matrix, (self.cols, self.rows))
        
        """
        name = "image" + picture_number + ".png"	#str(self.i)
        cv2.imwrite(name,self.cv_image) #save pics
        #if self.i >5:			
        #	self.i +=1
        """

        self.cv_image = cv2.cvtColor(self.cv_image, cv2.COLOR_BGR2GRAY)
        value = THRESHOLD
        if CALIBRATE:
            value=cv2.getTrackbarPos("Threshold", "PixyCam")

        ret,self.cv_image = cv2.threshold(self.cv_image,value,255,cv2.THRESH_BINARY)
        cv2.imshow("PixyCam", self.cv_image)
        cv2.waitKey(CAM_UPDATE_TIME)	#time in 
        
        if self.focus_pos == -1:
            self.center_pixel = self.cv_image.item(int(0.65*self.rows), self.cols/2)
            print("Center pixel is:", self.center_pixel)
            print("rows: ", self.rows, "columns: ", self.cols)
        """
        try:
            self.image_pub.publish(self.bridge.cv2_to_imgmsg(self.cv_image, "8UC1"))
        except CvBridgeError as e:
            print(e)
        """
       
        if not self.is_centered and not self.bottles_reached_cnt:    # if not centered and the first bottle hasn"t been reached"
            if self.focus_pos == -1:    # if focus_pos not initialized yet
                self.test_img = copy.deepcopy(self.cv_image)
                cv2.waitKey(10000)
                c_begin_area, c_end_area = self.findBottleArea()    # calculates also the current focus_pos so this will be done once
                cv2.waitKey(3000)
            self.pan2Center()   # sets the angular velocity to pan to the center of the four bottles. if camera is centered robot will stop turning and sets self.is_centered to True
        elif self.bottle_1_pos == self.bottle_2_pos:    # if botttles haven't been typecasted yet (initially the position of the two wanted bottles are both the same)
            self.test_img = copy.deepcopy(self.cv_image)
            c_begin_area, c_end_area = self.findBottleArea()
            bottles = self.typecastBottles(c_begin_area, c_end_area) # returns the position of the bottle tops in the current picture. All four bottles need to be in sight
            cv2.waitKey(3000)
        elif self.bottles_reached_cnt < 2:   # bottles have been typecasted and not all bottles have been reached
            if not self.is_aimed:
                self.turn2Bottle()    # sets the angular velocity to pan to the desired bottle. if camera center is on the wanted bottle, the robot will stop turning and sets self.is_aimed to True
            else:   # bottle is aimed. Now robot needs to drive to the aimed bottle
                if not self.is_reached:
                    self.drive2Bottle()
                elif(self.bottles_reached_cnt < 2): # if not both bottles have been reached...
                    
                    if self.all_purpose_cnt < 3000/CAM_UPDATE_TIME:
                        self.drive2Origin()
                    else:
                        # reset all for the next round:
                        self.vel_msg.linear.x = 0
                        self.vel_msg.angular.z = 0
                        self.twist_pub.publish(self.vel_msg)
                        print("Robot is at origin")
                        self.is_centered = False
                        self.is_aimed = False
                        self.is_reached = False
                        self.all_purpose_cnt = 0
                        self.bottles_reached_cnt += 1
        else: 
            print(" Job Done!!")
            self._result.done = True

    #----------------- END CALLBACK ----------------------
    def drive2Origin(self):
        cnt_2_left = 0
        cnt_2_right = 0
        while(not self.cv_image.item(int(0.65*self.rows), self.cols/2-cnt_2_left)):
            cnt_2_left +=1
            if cnt_2_left >= self.cols/2 -1:
                print("cnt_2_left", cnt_2_left)
                cv2.imshow("Counter Left Overflow", cnt_2_left)
                cnt_2_left = 0
                break
        while(not self.cv_image.item(int(0.65*self.rows), self.cols/2+cnt_2_right)):
            cnt_2_right +=1
            if cnt_2_right >= self.cols/2 -1:
                print("cnt_2_right", cnt_2_right)
                cv2.imshow("Counter Right Overflow", cnt_2_right)
                cnt_2_right = 0
                break

        diff = cnt_2_left - cnt_2_right
        #print("cnt_2_left: ", cnt_2_left,"cnt_2_right: ", cnt_2_right, self.vel_msg.angular.z)
        self.all_purpose_cnt +=1
        if self.all_purpose_cnt > 6000/CAM_UPDATE_TIME:
            self.vel_msg.linear.x = 0
            self.vel_msg.angular.z = 0
            #print("ROBOT BACK AT ORIGIN POSITION")
        elif abs(diff) > 3:
            if cnt_2_left > cnt_2_right:    # robot is slightly too much left right
                self.vel_msg.angular.z = 0.5*MAX_ANG_VEL
            else:    # robot is slightly too much left
                self.vel_msg.angular.z = -0.5*MAX_ANG_VEL 
        else:   # centered good enough
            self.vel_msg.angular.z = 0
            self.vel_msg.linear.x = -1*MAX_LIN_VEL
        self.twist_pub.publish(self.vel_msg)

    #----------------- END OF DRIVE2ORIGIN ---------------   
    def drive2Bottle(self):
        """ sets self.is_reached to True if the bottle has been reached and it increases the self.bottles_reached_cnt by one"""
        self.vel_msg.linear.x = MAX_LIN_VEL
        self.vel_msg.linear.y = 0
        self.vel_msg.linear.z = 0 
        self.vel_msg.angular.x = 0
        self.vel_msg.angular.y = 0
        self.vel_msg.angular.z = 0

        cnt_2_left = 0
        cnt_2_right = 0
        while(not self.cv_image.item(int(0.65*self.rows), self.cols/2-cnt_2_left)):
            cnt_2_left +=1
            if cnt_2_left >= self.cols/2 -1:
                print("cnt_2_left", cnt_2_left)
                cv2.imshow("Counter Left Overflow", cnt_2_left)
                cnt_2_left = 0
                break
        while(not self.cv_image.item(int(0.65*self.rows), self.cols/2+cnt_2_right)):
            cnt_2_right +=1
            if cnt_2_right >= self.cols/2 -1:
                print("cnt_2_right", cnt_2_right)
                cv2.imshow("Counter Right Overflow", cnt_2_right)
                cnt_2_right = 0
                break
        
        diff = cnt_2_left - cnt_2_right
        #print("cnt_2_left: ", cnt_2_left,"cnt_2_right: ", cnt_2_right, self.vel_msg.angular.z)
        if cnt_2_left + cnt_2_right > 0.4*self.cols:
             self.all_purpose_cnt += 1
        if self.all_purpose_cnt:
            self.all_purpose_cnt += 1
            
        if self.all_purpose_cnt > 2000/CAM_UPDATE_TIME:
            self.all_purpose_cnt += 1
            self.vel_msg.linear.x = 0.2*MAX_LIN_VEL
            self.vel_msg.angular.z = 0
            self.twist_pub.publish(self.vel_msg) # publish velocity msg
            cv2.waitKey(1000)
            self.is_reached = True
            print("Bottle reached")
            # publish the feedback
            self._feedback.first_reached = True
            self.all_purpose_cnt = 0
            cv2.waitKey(1000)
            self.vel_msg.linear.x = -MAX_LIN_VEL
            self.twist_pub.publish(self.vel_msg) # publish velocity msg
            cv2.waitKey(500)
        elif abs(diff) > 5:
            if cnt_2_left > cnt_2_right:    # robot is slightly too much left right
                self.vel_msg.angular.z = 0.5*MAX_ANG_VEL
            else:    # robot is slightly too much left
                self.vel_msg.angular.z = -0.5*MAX_ANG_VEL 
        else:   # centered good enough
            self.vel_msg.angular.z = 0
            self.vel_msg.linear.x = MAX_LIN_VEL

        self.twist_pub.publish(self.vel_msg) # publish velocity msg
    #----------------- END OF DRIVE2BOTTLE ---------------   
    def pan2Center(self):
        """
        self.vel_msg.linear.x = 0
        self.vel_msg.linear.y = 0
        self.vel_msg.linear.z = 0 
        self.vel_msg.angular.x = 0
        self.vel_msg.angular.y = 0
        self.vel_msg.angular.z = 0
        """
        #---update center_pixel and focus_pos---
        new_center_pixel = self.cv_image.item(int(0.65*self.rows), self.cols/2)    # usually there is less reflection slightly below the center. Therefore the 0.65 factor
        
        if self.prev_blob_color == -1:
            self.prev_blob_color == new_center_pixel
            self.blob_color = new_center_pixel

        if self.center_pixel == new_center_pixel:   # if contnous colors 
            self.same_color_cnt += 1
            if self.same_color_cnt > 3:
                self.blob_color = new_center_pixel
        else:
            self.same_color_cnt = 0

        if self.prev_blob_color != self.blob_color: # if color change  
            if self.center_pixel and not new_center_pixel:  # if a color change of the center pixel from --WHITE2BLACK-- occured a focus_pos update is required
                print("WHITE2BLACK")
                if self.vel_msg.angular.z < 0.0:  # if robot is turning right --> focus_pos needs to bee INcreased
                    self.focus_pos += 1
                    print("focus_pos:", self.focus_pos)
            elif not self.center_pixel and new_center_pixel:  # if a color change of the center pixel from --BLACK2WHITE-- occured a focus_pos update is required
                print("BLACK2WHITE")
                if self.vel_msg.angular.z > 0.0:  # if robot is turning left --> focus_pos needs to bee DEcreased
                    self.focus_pos -= 1
                    print("focus_pos:", self.focus_pos)
            self.blob_color = self.prev_blob_color

        self.center_pixel = new_center_pixel    # update center pixel color

        #---set velocities:---
        if self.focus_pos == 2 and self.blob_color:  # if the camera center is in the center of the four bottles 
            # fine adjustment:
            #print("fine adjustment")
            cnt_2_left = 1
            cnt_2_right = 1
            while(self.cv_image.item(int(0.65*self.rows), self.cols/2-cnt_2_left)):
                cnt_2_left +=1
                if cnt_2_left >= self.cols/2 -1:
                    print("cnt_2_left", cnt_2_left)
                    #cv2.imshow("Counter Left Overflow", cnt_2_left)
                    cnt_2_left = 0
                    break
            while(self.cv_image.item(int(0.65*self.rows), self.cols/2+cnt_2_right)):
                cnt_2_right +=1
                if cnt_2_right >= self.cols/2 -1:
                    print("cnt_2_right", cnt_2_right)
                    #cv2.imshow("Counter Right Overflow", cnt_2_right)
                    cnt_2_right = 0
                    break
            diff = cnt_2_left - cnt_2_right
            #print("cnt_2_left: ", cnt_2_left,"cnt_2_right: ", cnt_2_right, self.vel_msg.angular.z)
            if abs(diff) > 3:
                if cnt_2_left > cnt_2_right:    # robot is slightly too muchleft right
                    self.vel_msg.angular.z = 0.5*MAX_ANG_VEL
                else:    # robot is slightly too much left
                    self.vel_msg.angular.z = -0.5*MAX_ANG_VEL    
            else:   # centered good enough
                self.vel_msg.angular.z = 0
                self.is_centered = True
                print("Camera centered")
                self.test_img = copy.deepcopy(self.cv_image)  
                self.draw_x(self.test_img,self.cols/2,int(0.65*self.rows),5)
                cv2.imshow("Centered bottles", self.test_img)            
        else:   # if the camera center is not yet in the middle of the four bottles:
            if self.focus_pos != 2:
                if self.focus_pos < 2:  # camera center is still too much left
                    self.vel_msg.angular.z = -MAX_ANG_VEL   # turn right
                elif self.focus_pos == 3 and not new_center_pixel:    # if the camera center is right on the 3. bottle
                    self.vel_msg.angular.z = MAX_ANG_VEL* 0.5
                else:   # focus_pos is bigger than 2: --> camera center is still too much right
                    self.vel_msg.angular.z = MAX_ANG_VEL    # turn left
            else:   # camera center is on the second bottle
                self.vel_msg.angular.z = -MAX_ANG_VEL*0.5
        #print("vel_msg published")
        self.twist_pub.publish(self.vel_msg) # publish message

    #----------------- END OF PAN2CENTER -----------------    
    def findBottomValue(self):
        #-----------FIND POSITION OF BOTTLE BOTTOM-----------
        black_cnt = 0
        bottom_pos = np.zeros(4)
        bottle_length = np.zeros(4)
        white_cnt = 0
        for bottle in range(0, 4):
            for r in range(int(bottles[bottle,0]), self.rows):
                if not self.cv_image.item(r,int(bottles[bottle,1])): #if black pixel
                    if white_cnt:
                        black_cnt += white_cnt
                        white_cnt = 0
                    black_cnt +=1
                else: # white pixel
                    white_cnt +=1
                    
                if white_cnt > 18:
                    break
            bottom_pos[bottle] = black_cnt + bottles[bottle,0]
            bottle_length[bottle] = black_cnt
            black_cnt = 0
            white_cnt = 0
        
        bottle_length_mean = int(np.mean(bottle_length))
        bottom_mean = int(np.mean(bottom_pos))
        print ("bottle_length_mean", bottle_length_mean)
        print ("bottom_mean", bottom_mean)
        r_measure = int(bottom_mean-0.35*bottle_length_mean)
        print ("r_measure", r_measure)
        #-----------END OF FIND POSITION OF BOTTLE BOTTOM-----------
    
    def findBottleArea(self):
        """findBottleArea returns c_begin_area, c_end_area, self.focus_pos"""
        print("called findBottleArea()")
        #-----------FINDING BOTTLE AREA, BOTTLE WIDTHS CENTER POSITION-----------
        black_cnt = 0
        white_cnt = 0
        bottle_widths = np.zeros(4)
        bottle_cnt = 0
        first_detected = False
        first_white_cnt = 0
        big_white_right_gap = False
        r_measure = int(self.rows*0.65)
        self.draw_x(self.test_img, self.cols/2, r_measure,5)
        c_begin_area = 0
        c_end_area = self.cols - 1

        for c in range(self.left_border,self.cols - self.right_border):    # loop through columns from left to right
            if self.cv_image.item(r_measure,c) and not first_detected:  #if black and no bottle detected yet
                first_white_cnt += 1
                continue
            if first_white_cnt < 6:    # asuming that before the first bottle a bigger white space will be detected
                first_white_cnt = 0
                continue
            else:   # meaning we have seen a big enough white space before the first bottle or we have detected some bottles already
                first_detected = True
            if not self.cv_image.item(r_measure,c): #if black pixel
                if white_cnt < 7 and black_cnt:  # if there are just a few white pixels since the last black pixel it"s probably only a reflection
                    black_cnt += white_cnt 
                elif white_cnt < 50:   # slightly bigger white gap means now a new bottle detected
                    if BLACK_CNT_MAX > black_cnt > BLACK_CNT_MIN:
                        if bottle_cnt>=4:
                            break
                        bottle_widths[bottle_cnt] = black_cnt # save width of prior bottle
                        if bottle_cnt == 3:
                            c_end_area = c - white_cnt
                        elif not bottle_cnt:
                            c_begin_area = c - black_cnt - white_cnt
                        bottle_cnt += 1
                        cv2.line(self.test_img, (c-white_cnt-black_cnt,self.rows-10), (c-white_cnt,self.rows-10), 0) 
                    black_cnt = 0
                else:   # very big gap detected: it probably means that no bottle is following anymore. 
                    print("white_cnt was too big: ", white_cnt)
                    c_end_area = c - white_cnt 
                    big_white_right_gap = True
                    break

                black_cnt += 1
                white_cnt = 0

            else:   #if white pixel
                white_cnt +=1
                if black_cnt > BLACK_CNT_MAX:   # resets the black_cnt if its too big for a bottle
                    black_cnt = 0

            if c == int(self.cols/2):
                self.center_pixel = self.cv_image.item(r_measure, c)    # update center pixel color
                if not c_begin_area and (black_cnt>BLACK_CNT_MAX or white_cnt>50):
                    print("Checkpoint 1")
                    self.focus_pos = bottle_cnt
                else:
                    if white_cnt < 50 and black_cnt < BLACK_CNT_MAX and not self.center_pixel:  # if it's on a bottle
                        print("Checkpoint 2")
                        self.focus_pos = bottle_cnt + 2
                    print("Checkpoint 2")
                    self.focus_pos = bottle_cnt + 1
        
        print("first_white_cnt", first_white_cnt)
        if not self.center_pixel:
            print("The ", self.focus_pos, "Bottle is in the center of the picture")
        else:
            print("The ", self.focus_pos, ". space between the bottles is in the center of the picture")

        if bottle_cnt <= 3 and BLACK_CNT_MAX > black_cnt > BLACK_CNT_MIN: # if nothing black is coming after the last bottle it is not saved yet: So it gets saved now in case a blob with the widht of a bottle has been detected before
            bottle_widths[bottle_cnt] = black_cnt
            c_end_area = c-white_cnt
            cv2.line(self.test_img, (c-white_cnt-black_cnt,self.rows-10), (c-white_cnt,self.rows-10), 0) 
            bottle_cnt += 1
            self.focus_pos += 1
            print("Checkpoint 3")

            # if robot is turned to the left anf focus point is -1  then this doesnt work out 

        if bottle_cnt <=3:
            if big_white_right_gap:  #if not all four bottles have been detected and a big white gap on the right has been detected 
                self.focus_pos += 4 - bottle_cnt   # the focus_pos needs to be increased by the number of missing bottles
                #robot needs to turn right
                print("Checkpoint 4")
            if first_white_cnt > 60:
                # robot needs to turn left
                print("Checkpoint 5")
            

        bottle_width_mean = int(np.mean(bottle_widths))
        print("c_begin_area: ", c_begin_area, " = ", 100*c_begin_area/self.cols, "%")
        print("c_end_area: ", c_end_area, " = ", 100*c_end_area/self.cols, "%")
        cv2.line(self.test_img, (c_begin_area,0), (c_begin_area,self.rows-1), 0) 
        cv2.line(self.test_img, (c_end_area,0), (c_end_area,self.rows-1), 0)
        print("bottle widths: ",bottle_widths)
        print("mean bottle width: ",bottle_width_mean)
        print("focus_pos: ", self.focus_pos)
        print("bottle_cnt: ", bottle_cnt)

        cv2.imshow("Bottle Area",self.test_img)
        

        return c_begin_area, c_end_area

    
    
    #-----------------END OF FIND BOTTLE AREA-------------
    def typecastBottles(self, c_begin_area, c_end_area):

        """self.bottle_1_pos and self.bottle_2_pos gets set"""
        print("called typecastBottles()")
        #-----------TYPECASTING THE BOTTLES:-----------
        purely_white_cnt = 0
        #all four bottles should be within sight at this time
        purely_white_cnt = 0
        bottle_cnt = 0
        bottles = np.zeros((4,2))

        #cv2.imshow("turnToBottle", self.test_img)
        cv2.waitKey(3000)
        for r in range(0,self.rows):    # loop through pixels in a row
            black_detected = False
            for c in range(c_begin_area, c_end_area):    # loop through pixels in a column
                #print(self.cv_image.item(r,c))
                #print("c:", c, "r:", r)
                if not self.cv_image.item(r,c): # if black detected in this row
                    black_detected = True
                    if purely_white_cnt > WHITE_LINES_ABOVE: # if the prior n rows in the determined c_area were completely white it is likely that a black pixel is part of a bottle
                        if bottle_cnt == 4:
                            break
                        new_bottle = True
                        for b in range(0, bottle_cnt + 1):
                            #print("abs(c-bottles[", b, ",1])","abs(", c, "-",bottles[b,1],")=", abs(c-bottles[b,1]))
                            if abs(c-bottles[b,1]) < 20:  #same bottle as bottles[b] detected
                                new_bottle = False
                                break
                        if new_bottle:
                            print(bottle_cnt + 1, ". bottle detected at c:",c, "r:", r)
                            if bottle_cnt < 2:
                                self.draw_x(self.test_img, c, r, 4, "WINE")
                            else: 
                                self.draw_x(self.test_img, c, r, 4, "BEER")
                            
                            bottles[bottle_cnt] = r,c
                            bottle_cnt += 1

            if bottle_cnt == 4:
                print("end for loop because 4 bottles have been detected already")
                break
            if not black_detected:
                purely_white_cnt += 1
            elif purely_white_cnt < WHITE_LINES_ABOVE:
                purely_white_cnt = 0
      
        bottle_order = np.argsort(bottles[:,1]) # returns the indices of bottles sorted by the c value in increasing order. bottle_order[x]: x:position, value: determines if beer(value>=2) or wine(value<2)
        print(bottle_order)
        print("From left to write we have the following order:")
        for x in range(0,4):
            if(bottle_order[x]<2):
                    print("    ",x+1, ". WINE")
            else:
                    print("    ",x+1, ". BEER")


        if self.wanted_bottle_1 != self.wanted_bottle_2:    # if we have to look for two different bottles...
            if self.wanted_bottle_1 == WINE:    # if wanted_bottle_1 = wine and wanted_bottle_2 = beer
                self.bottle_1_pos = np.argwhere(bottle_order == 0)[0,0] + 1
                self.bottle_2_pos = np.argwhere(bottle_order == 3)[0,0] + 1
                print("np.argwhere(bottle_order == 3)", np.argwhere(bottle_order == 3)[0,0])
                print("np.argwhere(bottle_order == 0)", np.argwhere(bottle_order == 0)[0,0])
            else:   # if wanted_bottle_1 = beer and wanted_bottle_2 = wine
                self.bottle_1_pos = np.argwhere(bottle_order == 3)[0,0] + 1
                self.bottle_2_pos = np.argwhere(bottle_order == 0)[0,0] + 1
                print("np.argwhere(bottle_order == 3)", np.argwhere(bottle_order == 3)[0,0])
                print("np.argwhere(bottle_order == 0)", np.argwhere(bottle_order == 0)[0,0])
        else:   # if both wanted bottles have the same type...
            if self.wanted_bottle_1 == WINE:    # if wanted_bottleS = WINE
                self.bottle_1_pos = np.argwhere(bottle_order == 0)[0,0] + 1
                self.bottle_2_pos = np.argwhere(bottle_order == 1)[0,0] + 1
                print("np.argwhere(bottle_order == 3)", np.argwhere(bottle_order == 1)[0,0])
                print("np.argwhere(bottle_order == 0)", np.argwhere(bottle_order == 0)[0,0])
            else:   # if wanted_bottleS = WINE
                self.bottle_1_pos = np.argwhere(bottle_order == 3)[0,0] + 1
                self.bottle_2_pos = np.argwhere(bottle_order == 2)[0,0] + 1
                print("np.argwhere(bottle_order == 3)", np.argwhere(bottle_order == 1)[0,0])
                print("np.argwhere(bottle_order == 0)", np.argwhere(bottle_order == 0)[0,0])

        print("The first bottle we are aiming for is on position ", self.bottle_1_pos)
        print("The second bottle we are aiming for is on position ", self.bottle_2_pos)
        cv2.imshow("detected bottles", self.test_img)
        return bottles
    
    #----------------- END OF DETECTING THE BOTTLES ------
    def turn2Bottle(self):
        self.vel_msg.linear.x = 0
        self.vel_msg.linear.y = 0
        self.vel_msg.linear.z = 0 
        self.vel_msg.angular.x = 0
        self.vel_msg.angular.y = 0

        bottle_pos = 0
        if self.bottles_reached_cnt == 0:   # robot needs to turn to self.bottle_1_pos
            bottle_pos = self.bottle_1_pos
        elif self.bottles_reached_cnt == 1:   # robot needs to turn to self.bottle_2_pos
            bottle_pos = self.bottle_2_pos
        else:
            print("ERROR:   ----ROBOT DOESN'T KNOW WHER IT SHOULD TURN----")
        """
            #---update center_pixel and focus_pos---
            new_center_pixel = self.cv_image.item(int(0.65*self.rows),self.cols/2)    # usually there is less reflection slightly below the center. Therefore the 0.65 factor
            if self.center_pixel and not new_center_pixel:  # if a color change of the center pixel from --WHITE2BLACK-- occured a focus_pos update is required
                print("WHITE2BLACK")
                if self.vel_msg.angular.z < 0.0:  # if robot is turning right --> focus_pos needs to bee INcreased
                    self.focus_pos += 1
                    print("focus_pos:", self.focus_pos)
            elif not self.center_pixel and new_center_pixel:  # if a color change of the center pixel from --BLACK2WHITE-- occured a focus_pos update is required
                print("BLACK2WHITE")
                if self.vel_msg.angular.z > 0.0:  # if robot is turning left --> fofcus_pos needs to bee DEcreased
                    self.focus_pos -= 1
                    print("focus_pos:", self.focus_pos)
            self.center_pixel = new_center_pixel    # update center pixel color
        """


        #---update center_pixel and focus_pos---
        new_center_pixel = self.cv_image.item(int(0.65*self.rows), self.cols/2)    # usually there is less reflection slightly below the center. Therefore the 0.65 factor
        
        if self.prev_blob_color == -1:
            self.prev_blob_color == new_center_pixel
            self.blob_color = new_center_pixel

        if self.center_pixel == new_center_pixel:   # if contnous colors 
            self.same_color_cnt += 1
            if self.same_color_cnt > 3:
                self.blob_color = new_center_pixel
        else:
            self.same_color_cnt = 0

        if self.prev_blob_color != self.blob_color: # if color change  
            if self.center_pixel and not new_center_pixel:  # if a color change of the center pixel from --WHITE2BLACK-- occured a focus_pos update is required
                print("WHITE2BLACK")
                if self.vel_msg.angular.z < 0.0:  # if robot is turning right --> focus_pos needs to bee INcreased
                    self.focus_pos += 1
                    print("focus_pos:", self.focus_pos)
            elif not self.center_pixel and new_center_pixel:  # if a color change of the center pixel from --BLACK2WHITE-- occured a focus_pos update is required
                print("BLACK2WHITE")
                if self.vel_msg.angular.z > 0.0:  # if robot is turning left --> focus_pos needs to bee DEcreased
                    self.focus_pos -= 1
                    print("focus_pos:", self.focus_pos)
            self.blob_color = self.prev_blob_color

        self.center_pixel = new_center_pixel    # update center pixel color



        #---set velocities:---

        if self.focus_pos == bottle_pos and not new_center_pixel:  # if the camera center is on the wanted bottle....
            # fine adjustment:
            cnt_2_left = 0
            cnt_2_right = 0
            while(not self.cv_image.item(int(0.65*self.rows), self.cols/2-cnt_2_left)):
                cnt_2_left +=1
                if cnt_2_left >= self.cols/2 -1:
                    print("cnt_2_left", cnt_2_left)
                    cv2.imshow("Counter Left Overflow", cnt_2_left)
                    cnt_2_left = 0
                    break
            while(not self.cv_image.item(int(0.65*self.rows), self.cols/2+cnt_2_right)):
                cnt_2_right +=1
                if cnt_2_right >= self.cols/2 -1:
                    print("cnt_2_right", cnt_2_right)
                    cv2.imshow("Counter Right Overflow", cnt_2_right)
                    cnt_2_right = 0
                    break
            #print("cnt_2_left: ", cnt_2_left,"cnt_2_right: ", cnt_2_right, self.vel_msg.angular.z)
            diff = cnt_2_left - cnt_2_right
            if abs(diff) >= 3:
                if cnt_2_left > cnt_2_right:    # robot is slightly too much right
                    self.vel_msg.angular.z = 0.3*MAX_ANG_VEL
                else:    # robot is slightly too much left
                    self.vel_msg.angular.z = -0.3*MAX_ANG_VEL    
            else:   # centered good enough
                self.vel_msg.angular.z = 0
                self.twist_pub.publish(self.vel_msg) # publish message
                self.is_aimed = True
                self.test_img = copy.deepcopy(self.cv_image)
                self.draw_x(self.test_img,self.cols/2, self.rows-10,5, "aim")
                cv2.imshow("aimed bottle",self.test_img)
                print("Camera center is aiming the", self.bottles_reached_cnt + 1, ". wanted bottle")  
                cv2.waitKey(5000)      
        else:   # if the camera center is not yet in the middle of the wanted bottles:
            if self.focus_pos == bottle_pos - 1 and new_center_pixel:    # camera focus is on the left side of the wanted bottle 
                self.vel_msg.angular.z = -0.5*MAX_ANG_VEL
            elif self.focus_pos == bottle_pos and new_center_pixel:      # camera focus is on the left right of the wanted bottle 
                self.vel_msg.angular.z = 0.5*MAX_ANG_VEL
            elif self.focus_pos > bottle_pos:    # if the camera center is still too much right
                self.vel_msg.angular.z = MAX_ANG_VEL
            else:   # bottle is too much left
                self.vel_msg.angular.z = -MAX_ANG_VEL
                        
        self.twist_pub.publish(self.vel_msg) # publish message
        return False

    #----------------- END OF TURNTOBOTTLE ---------------
    def workWithSaved(self):
        #use saved pics:
        name = "/home/turtlebot/catkin_ws/image" + str(self.picture_number) + ".png"	  #str(self.i)
        self.cv_image = cv2.imread(name, 0)
        self.rows, self.cols = self.cv_image.shape
        #self.cv_image = cv2.cvtColor(self.cv_image, COLOR_BGR2GRAY)
        value_old = 0
        value = THRESHOLD
        ret,self.cv_image = cv2.threshold(self.cv_image,value,255,cv2.THRESH_BINARY)
        if CALIBRATE:
            cv2.createTrackbar("Threshold","PixyCam",40,255,nothing)
        #if self.i >5:			
        #	self.i +=1

        while True:
            value = cv2.getTrackbarPos("Threshold", "PixyCam")
            self.cv_image = cv2.imread(name, 0)
            if value != value_old:
                value_old = value
                print("Trackbar Pose:", value)
                ret,self.cv_image = cv2.threshold(self.cv_image,value,255,cv2.THRESH_BINARY)
                cv2.imshow("PixyCam", self.cv_image)
                cv2.waitKey(4000)	#time in ms
                self.turn2Bottle()
            cv2.waitKey(500)	#time in ms
    #----------------- END OF WORKWITHSAVED --------------
    def draw_x(self,img, col, row, size=10, text = None):
        cv2.line(img, (col-size,row-size), (col+size,row+size),100) 
        cv2.line(img, (col-size,row+size), (col+size,row-size), 100)
        cv2.putText(img, text, (col-15,row-size), cv2.FONT_HERSHEY_SIMPLEX,0.3, 40)   
        


def main(args):

    print("main of find_bottles_py.py")
    rospy.init_node('find_bottles_py')
    server = FindBottlesAction(rospy.get_name())
    #ic = image_converter(WINE, WINE)
    print("server created")
    try:
        rospy.spin()
    except KeyboardInterrupt:
        print("Shutting down")
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main(sys.argv)
